<?php
// Application middleware

// e.g: $app->add(new \Slim\Csrf\Guard);

namespace App\Middleware;

class Middleware
{
	protected $container;

	public function __construct($container){
		$this->container = $container;
	}
}