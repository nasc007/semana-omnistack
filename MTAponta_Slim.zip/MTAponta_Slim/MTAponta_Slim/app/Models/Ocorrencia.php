<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ocorrencia extends Model
{
    protected $table = 'mt_ocorrencias';

    protected $primaryKey = 'cod_ocorrencia';
    
    protected $fillable = ['cod_tipo_ocorrencia', 
    'cod_agente',
    'dsc_inscricao',
    'vlr_pos_x',
    'vlr_pos_y',
    'dat_ocorrencia',
    'nom_atendente',
    'tip_atendente',
    'dsc_observacao'];

	public $timestamps = false;
}