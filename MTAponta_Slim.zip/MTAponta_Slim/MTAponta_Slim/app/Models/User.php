<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
	protected $table = 'user';

	protected $primaryKey = 'id';
	
	protected $fillable = [
		'email',
		'name',
		'password',
		'vlr_pos_x',
		'vlr_pos_y'
	];

	protected $hidden = ['password'];

	public $timestamps = false;
}