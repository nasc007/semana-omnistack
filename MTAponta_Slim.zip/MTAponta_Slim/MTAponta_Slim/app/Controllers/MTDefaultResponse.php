<?php

namespace App\Controllers;

class MTDefaultResponse implements \JsonSerializable
{
    function __construct($status, $data, $message, $token='')
    {
        $this->status = $status;
        $this->message = $message;
        $this->data = $data;
        $this->token = $token;        
    }

    public function jsonSerialize()
    {
        if(!$this->token)
            return array_filter(['status' => $this->status, 'message' => $this->message,'data' => $this->data]);

        return array_filter(['status' => $this->status, 'message' => $this->message,'data' => $this->data,'token' => $this->token]);
    }

    protected $status;
    protected $message;
    protected $data;
    protected $token;
}