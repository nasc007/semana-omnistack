<?php

namespace App\Controllers;

use App\Controllers\Controller;
use Slim\Http\Request;

class UsuarioController extends Controller
{
    public function index($request, $response, $args){
        $sth = $this->pdo->prepare("SELECT * FROM usuario WHERE nome = '".$args['nome']."' AND email = '".$args['email']."'");
        $sth->execute();
        $retorno = $sth->fetchALL();
        
        //var_dump($retorno); die;
        return $this->response->withJson($retorno);
    }

}