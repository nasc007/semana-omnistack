<?php

namespace App\Controllers;

use App\Controllers\Controller;

class GeoJsonController extends Controller
{
    public function lote($request, $response, $args){
        $tile = '';
        $sth = $this->pdo->prepare("with outro as (SELECT  concat(i.zona,i.quadra,i.lote) as inscricao, i.proprietario, i.compromissario, i.logradouro, i.nimovel FROM  principal i ), 
        outra as ( SELECT geom as shape, i.*,cod_tipo_ocorrencia,cod_ocorrencia  from lotes left join outro i on insclote = inscricao left join mt_ocorrencias m on m.dsc_inscricao = inscricao
				 WHERE st_contains(geom, st_transform(ST_SetSrid('POINT(".$request->getParam('lat').' '.$request->getParam('long').")'::geometry,3857),31982)) limit 1)

        SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features 
                            from (select row_to_json(p) from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(shape,3857))::json 
                            AS geometry, row_to_json(row(inscricao, proprietario, compromissario, logradouro, nimovel, cod_tipo_ocorrencia, cod_ocorrencia)) as properties 
                            from outra)p)m)t
        ");
        $sth->execute();
        $tile = $sth->fetchALL();
        
        return $response->withAddedHeader('Access-Control-Allow-Origin', '*')->withJson($tile[0]['coordenada']);
    }

    public function lote_($request, $response, $args){
        $tile = '';
        $sth = $this->pdo->prepare("with outro as (SELECT  concat(i.zona,i.quadra,i.lote) as inscricao, i.proprietario, i.compromissario, i.logradouro, i.nimovel FROM  principal i ), 
        outra as ( SELECT INSCLOTE, geometry, i.*, cod_tipo_ocorrencia  from lotes left join outro i on INSCLOTE = inscricao left join mt_ocorrencias m on m.dsc_inscricao = inscricao
                 WHERE st_contains(geometry, st_transform(ST_SetSrid('POINT(".$request->getParam('lat').' '.$request->getParam('long').")'::geometry,3857),31982)) limit 1)

        SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features from (select row_to_json(p) 
            from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(geometry,3857))::json AS geometry, row_to_json(row(inscricao, proprietario, compromissario, logradouro, nimovel, cod_tipo_ocorrencia)) as properties from outra)p)m)t
        ");
        $sth->execute();
        $tile = $sth->fetchALL();
        
        return $response->withAddedHeader('Access-Control-Allow-Origin', '*')->withJson($tile[0]['coordenada']);
    }

    public function centro($request, $response, $args){
        $tile = '';
        $sth = $this->pdo->prepare("SELECT avg(st_x(geom)) as x, avg(st_y(geom)) as y from (select st_transform(st_centroid(st_collect(st_envelope(geom)))::geometry,3857) as geom from lotes)g
        ");
        $sth->execute();
        $tile = $sth->fetch();
        $returnValue = [floatval($tile['x']),floatval($tile['y'])];
        //var_dump ($returnValue); die;
        
        return $response->withAddedHeader('Access-Control-Allow-Origin', '*')->withJson($returnValue);
    }
}