<?php

namespace App\Controllers;

use App\Controllers\Controller;
use App\Third\Giap;

class PesquisaController extends Controller
{
    public function pesquisa($request, $response, $args){
        $tile = '';

        
        $sql = "with outro as (SELECT  concat(i.zona,i.quadra,i.lote) as inscricao, i.proprietario, i.compromissario, i.logradouro, i.nimovel FROM  principal i ), 
        outra as ( SELECT ST_PointOnSurface(geom) as shape, i.*,cod_tipo_ocorrencia  
                    from lotes left join outro i on insclote = inscricao left join mt_ocorrencias m on m.dsc_inscricao = inscricao";
        if($request->getParam('insc') || $request->getParam('lograd') || $request->getParam('prop'))
            $sql .= " WHERE ";
        
        $where = '';
        if($request->getParam('insc'))
        {
            $where .= " i.inscricao ILIKE '%".$request->getParam('insc')."%' ";
        }

        if($request->getParam('lograd'))
        {
            if($where != '')
            {
                $where.= " OR ";
            }
            $where.= "i.logradouro ILIKE '%".$request->getParam('lograd')."%' ";
            if($request->getParam('num'))
            {
                $where.=" AND i.nimovel = " . $request->getParam('num');
            }
        }

        if($request->getParam('prop'))
        {
            if($where != '')
            {
                $where.= " AND ";
            }
            $where.="i.proprietario ILIKE '%".$request->getParam('prop')."%' LIMIT 1000";
        }

        $sql .= $where.")
        SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features 
        from (select row_to_json(p) from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(shape,3857))::json 
        AS geometry, row_to_json(row(inscricao, proprietario, compromissario, logradouro, nimovel, cod_tipo_ocorrencia)) as properties 
        from outra)p)m)t
        ";
        $sth = $this->pdo->prepare($sql);
        $sth->execute();
        //var_dump($sth);die;
        $tile = $sth->fetchALL();

        return $tile[0]['coordenada'];
    }

    public function pesquisarapida($request, $response, $args){
        $tile = '';

        $sql = "with outro as (SELECT  concat(i.zona,i.quadra,i.lote) as inscricao, i.proprietario, i.compromissario, i.logradouro, i.nimovel FROM  principal i ), 
        outra as ( SELECT ST_PointOnSurface(geom) as shape, i.*,cod_tipo_ocorrencia  
                    from lotes left join outro i on insclote = inscricao left join mt_ocorrencias m on m.dsc_inscricao = inscricao 
                    WHERE inscricao ILIKE '".$args['inscricao']."%')
        SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features 
        from (select row_to_json(p) from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(shape,3857))::json 
        AS geometry, row_to_json(row(inscricao, proprietario, compromissario, logradouro, nimovel, cod_tipo_ocorrencia)) as properties 
        from outra)p)m)t
        ";
        //var_dump($sql); die;
        $sth = $this->pdo->prepare($sql);
        $sth->execute();
        $tile = $sth->fetchALL();

        //var_dump($tile); die;

        return $response->withAddedHeader('Access-Control-Allow-Origin', '*')->withJson($tile[0]['coordenada']);
    }

    public function pesquisa_avancada($request, $response, $args){
        $tile = '';

        $sql = "with outro as (SELECT  concat(i.zona,i.quadra,i.lote) as inscricao, i.proprietario, i.compromissario, i.logradouro, i.nimovel FROM  principal i ), 
        outra as ( SELECT DISTINCT ST_PointOnSurface(geom) as shape, i.* from lotes left join outro i on insclote = inscricao 
                    left join mt_ocorrencias m on m.dsc_inscricao = inscricao";
        if($request->getParam('insc') || $request->getParam('lograd') || $request->getParam('prop'))
            $sql .= " WHERE ";
        
        $where = '';
        if($request->getParam('insc'))
        {
            $where .= " i.inscricao ILIKE '%".$request->getParam('insc')."%' ";
        }

        if($request->getParam('lograd'))
        {
            if($where != '')
            {
                $where.= " OR ";
            }
            $where.= "i.logradouro ILIKE '%".$request->getParam('lograd')."%' ";
            if($request->getParam('num'))
            {
                $where.=" AND i.nimovel = " . $request->getParam('num');
            }
        }

        if($request->getParam('prop'))
        {
            if($where != '')
            {
                $where.= " AND ";
            }
            $where.="i.proprietario ILIKE '%".$request->getParam('prop')."%' LIMIT 1000";
        }

        $sql .= $where.")
        SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features 
        from (select row_to_json(p) from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(shape,3857))::json 
        AS geometry, row_to_json(row(inscricao, proprietario, compromissario, logradouro, nimovel)) as properties 
        from outra)p)m)t
        ";
        $sth = $this->pdo->prepare($sql);
        $sth->execute();
        //var_dump($sth);die;
        $tile = $sth->fetchALL();

        return $tile[0]['coordenada'];
    }
}
        