<?php
namespace App\Controllers\API;

use App\Controllers\ApiController;
use App\Models\User;
use App\Validation\Rules\EmailAvailable;
use Respect\Validation\Validator as v;
use \Firebase\JWT\JWT;
use \Firebase\JWT\ExpiredException;
use Illuminate\Database\Capsule\Manager as DB;

class UsuarioApiController extends ApiController
{	
	public function create($request, $response, $args){
		
		try{
			$validation = $this->validator->validate($request, [
				'email' => v::noWhitespace()->notEmpty()->emailAvailable(),
				'name' => v::notEmpty()->alpha(),
				'password' => v::noWhitespace()->notEmpty()
			]);
	
			if($validation->failed()){
				throw new \Exception(json_encode($validation));
			}
			
			$user = User::create(array(				
				'name' => $request->getParam('name'),
				'email' => $request->getParam('email'),
				'password' => password_hash($request->getParam('password'), PASSWORD_DEFAULT),
				//'localizacao' => DB::raw("public.ST_SETSRID(public.ST_POINT(".$request->getParam('localizacao')."),31982)"),
				'vlr_pos_x' => $request->getParam('vlr_pos_x'),
				'vlr_pos_y' => $request->getParam('vlr_pos_y')
			));
			

			//$user->localizacao = DB::raw("public.ST_POINT(".$request->getParam('localizacao').")");
			//$user->save();
			
			return $response->withJson($this->getDefaultMessage("ok", "Incluído com sucesso.", $user->id));
		} catch(PDOException  | \Exception | EmailAvailableException $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
	}

	public function login($request, $response, $args){
		try {

			$email = $request->getParam('email');
			$password = $request->getParam('password');
			$user = User::where('email',$email)->first();
			
			if(!$user){
				throw new \Exception('Usuário não encontrado!');
			}

			if(!$user->ativo){
				throw new \Exception('Usuario não habilitado!');
			}

			if( !password_verify($password, $user->password)){
				throw new \Exception('Senha inválida!');
			}
			
			$issuedat_claim = time(); // issued at
			$notbefore_claim = $issuedat_claim + 10; //not before in seconds
			$expire_claim = $issuedat_claim + 86400; //1 day in seconds // expire time in seconds
			$token = array(
				"iss" => $this->settings['security']['issuer_claim'],
				"aud" => $this->settings['security']['audience_claim'],
				"iat" => $issuedat_claim,
				"nbf" => $notbefore_claim,
				"exp" => $expire_claim,
				"data" => $user->toArray()
			);

			$jwt = JWT::encode($token, $this->settings['security']['secret_key']);

			return $response->withJson($this->getDefaultMessage("ok", $user, "", $jwt));
		} catch (PDOException | \Exception $e) {
			return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
		}
	}

	public function pass($request, $response, $args){
		try {
			if(!$request->getParam('password'))
				throw new \Exception('Senha inválida');
				
            $user = $this->authenticated_user;
            if(!$user)
                throw new Exception('Não autenticado');

            $user->password = password_hash($request->getParam('password'), PASSWORD_DEFAULT);
            $user->save();

            return $response->withJson($this->getDefaultMessage("ok", $user, "Senha alterada"));
		} 
		catch ( Exception | ExpiredException $e) {
			return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
		}
	}

	public function location($request, $response, $args){
		try {
			$user = $this->authenticated_user;
            if(!$user)
				throw new Exception('Não autenticado');
			
			$user->vlr_pos_x = $request->getParam('vlr_pos_x');
			$user->vlr_pos_y = $request->getParam('vlr_pos_y');

			$user->save();

			return $response->withJson($this->getDefaultMessage("ok", $user, "Posição gravada!"));
		} catch (Exception | ExpiredException $e) {
			return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
		}	
	}
	
}