<?php

namespace App\Controllers;

use App\Controllers\Controller;
use App\Models\Ocorrencia;
use Slim\Http\Request;
use Respect\Validation\EmailAvailable;
use Respect\Validation\Validator as v;

class OcorrenciaController extends Controller
{
    public function create($request, $response, $args){
        try {
            $ocorrecia = Ocorrencia::create(array(
                'cod_tipo_ocorrencia' => $request->getParam('cod_tipo_ocorrencia'),//integer
                'cod_agente' => $request->getParam('cod_agente'),//integer
                'dsc_inscricao' => $request->getParam('dsc_inscricao'),//char
                'vlr_pos_x' => $request->getParam('vlr_pos_x'),//double
                'vlr_pos_y' => $request->getParam('vlr_pos_y'),//double
                'dat_ocorrencia' => $request->getParam('dat_ocorrencia'),//AAAA-MM-DD HH:MM:SS
                'nom_atendente' => $request->getParam('nom_atendente'),//char
                'tip_atendente' => $request->getParam('tip_atendente'),//integer
                'dsc_observacao' => $request->getParam('dsc_observacao'),//char
            ));
        
            $directory = $this->settings['upload_path'];
            $uploadedFiles = $request->getUploadedFiles();
        
            // handle single input with single file upload
            foreach ($uploadedFiles['file'] as $uploadedFile) {
                if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                    $this->moveUploadedFile($directory, $uploadedFile)."\r\n";
                }
            }

            //if(giap::geraOcorrencia(dsc_inscricao, $uploadedFiles) == deucerto)
            /*{
                $ocorrecia.status = 1;
                $ocorrencia.save();
            }*/
            
            return $response->withJson($this->getDefaultMessage("ok", $ocorrecia, " Incluído com sucesso."));
        } catch(PDOException $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
        //var_dump($response); die;
    }

    public function update($request, $response, $args){
        try {
            $ocorrencia = Ocorrencia::find($args['id']);
            if(!$ocorrencia){
                throw new \Exception("Ocorrência não encontrada");
            }
            
            $ocorrencia->cod_tipo_ocorrencia = $request->getParam('cod_tipo_ocorrencia');
            $ocorrencia->cod_agente = $request->getParam('cod_agente');
            $ocorrencia->dsc_inscricao = $request->getParam('dsc_inscricao');
            $ocorrencia->vlr_pos_x = $request->getParam('vlr_pos_x');
            $ocorrencia->vlr_pos_y = $request->getParam('vlr_pos_y');
            $ocorrencia->dat_ocorrencia = $request->getParam('dat_ocorrencia');
            $ocorrencia->nom_atendente = $request->getParam('nom_atendente');
            $ocorrencia->tip_atendente = $request->getParam('tip_atendente');
            $ocorrencia->dsc_observacao = $request->getParam('dsc_observacao');

            $ocorrencia->save();
            
            $directory = $this->settings['upload_path'];
            $uploadedFiles = $request->getUploadedFiles();
        
            foreach ($uploadedFiles['file'] as $uploadedFile) {
                if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                    $this->moveUploadedFile($directory, $uploadedFile)."\r\n";
                }
            }
            return $response->withJson($this->getDefaultMessage("ok", null, "Alterado com sucesso."));
        } catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }    
  

    public function moveUploadedFile($directory, $uploadedFile)
    {
        $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $uploadedFile->getClientFilename());
        
        return $directory . DIRECTORY_SEPARATOR . $uploadedFile->getClientFilename();
    }
 

    public function get_ocorrencia($request, $response, $args){
        $sth = $this->pdo->prepare("SELECT *, 'Agente Cadastrado' as nome_agente, (SELECT T.nome FROM tipo_ocorrencia T WHERE T.id = O.cod_tipo_ocorrencia LIMIT 1) 
                                                as dsc_ocorrencia FROM mt_ocorrencias O WHERE O.dsc_inscricao = '".$args['inscricao']."' ORDER BY cod_ocorrencia DESC");
        $sth->execute();
        $retorno = $sth->fetchALL();
        //var_dump ($retorno); die;
        $retVal=[];
        foreach ($retorno as $row) {
            $row['fotos'] = $this->getFotos($row["dsc_inscricao"],$row["cod_ocorrencia"],$row["data"]);
            $retVal[] = $row;
        }
        //print_r($retorno); die;
        return $this->response->withJson($retVal);
    }   

    public function get_ocorrencia_tipo($request, $response, $args){
        //var_dump($args['inscricao']);die;
        $sth = $this->pdo->prepare("SELECT * FROM mt_ocorrencias WHERE dsc_inscricao = '".$args['inscricao']."' AND cod_ocorrencia = '".$args['cod_ocorrencia']."'");
        $sth->execute();        
        $retorno = $sth->fetchALL();
        $retVal=[];
        foreach ($retorno as $row) {
            $row['fotos'] = $this->getFotos($row["dsc_inscricao"],$row["cod_ocorrencia"],$row["data"]);
            $retVal[] = $row;
        }
        //print_r($retorno); die;
        return $this->response->withJson($retVal);
    }  

    public function getFotos($dsc_inscricao,$cod_ocorrencia,$data)
    {
        $files = [];

        //$fileName = "IMG_".$dsc_inscricao."_".$data."*.*";
        $fileName = "IMG_".$dsc_inscricao."_".$cod_ocorrencia."_*.*";
        $directory = $this->settings['upload_path'];
        foreach (glob($directory.DIRECTORY_SEPARATOR.$fileName) as $arquivo){
            $files[] = basename($arquivo);
        }
        
        return $files;
    }

    public function downloadPhotos($request, $response, $args)
    {
        $directory = $this->settings['upload_path'];
        $file = $directory . DIRECTORY_SEPARATOR . $args['filename'];
        $fh = fopen($file, 'rb');

        $stream = new \Slim\Http\Stream($fh); // create a stream instance for the response body

        return $response->withHeader('Content-Type', 'application/force-download')
                        ->withHeader('Content-Type', 'application/octet-stream')
                        ->withHeader('Content-Type', 'application/download')
                        ->withHeader('Content-Description', 'File Transfer')
                        ->withHeader('Content-Transfer-Encoding', 'binary')
                        ->withHeader('Content-Disposition', 'attachment; filename="' . basename($file) . '"')
                        ->withHeader('Expires', '0')
                        ->withHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0')
                        ->withHeader('Pragma', 'public')
                        ->withBody($stream);
    }

    public function deletePhotos($request, $response, $args)
    {
        try {
            $directory = $this->settings['upload_path'];
            $file = $directory . DIRECTORY_SEPARATOR . $args['filename'];
            unlink ($file);

            return $response->withJson($this->getDefaultMessage("ok", null, "Excluido com sucesso."));
        } catch (PDOException $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
        
    }

    public function ocorrenciaTipo($request, $response, $args)
    {
        try {
            $ocorrencia = '';
            $sth = $this->pdo->prepare("SELECT A.cod_ocorrencia, A.dat_ocorrencia, 'Agente Cadastrado' as agente,
            A.dsc_inscricao,
            (SELECT B.nome FROM tipo_ocorrencia B WHERE B.id = A.cod_tipo_ocorrencia)
                            FROM mt_ocorrencias A WHERE A.dsc_inscricao = '".$args['inscricao']."' ORDER BY cod_ocorrencia DESC");
            $sth->execute();
            $retorno = $sth->fetchALL();
            $retVal=[];
            foreach ($retorno as $row) {
                $row['fotos'] = $this->getFotos($row["dsc_inscricao"],$row["cod_ocorrencia"],$row["data"]);
                $retVal[] = $row;
            }

            return $this->response->withJson($retVal);
        } catch (PDOException $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
        
    }
}