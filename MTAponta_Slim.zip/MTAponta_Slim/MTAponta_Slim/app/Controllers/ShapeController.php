<?php

namespace App\Controllers;

use App\Controllers\Controller;
use Slim\Http\Request;
use Slim\Http\UploadedFile;

class ShapeController extends Controller
{
    public function uploading($request, $response, $args){
        try{
            $directory = $this->settings['upload_shape'];
            $uploadedFiles = $request->getUploadedFiles();
            // handle single input with single file upload
            foreach ($uploadedFiles['file'] as $uploadedFile) {
                if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                    $file = $this->moveUploadedFile($directory, $uploadedFile);
                    $this->importShape($this->settings['shp2pgsql']['s'],$this->settings['shp2pgsql']['g'],$this->settings['shp2pgsql']['table'], $file);
                }
            }
           return $response->withJson($this->getDefaultMessage("ok", null, "Incluído com sucesso."));
        } catch(PDOException $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    public function moveUploadedFile($directory, $uploadedFile)
    {
        //var_dump ($directory, $uploadedFile);die;
        $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $uploadedFile->getClientFilename());
        
        return $directory . DIRECTORY_SEPARATOR . $uploadedFile->getClientFilename();
    }


    public function importShape($srid, $geomColumnName, $tableName, $shapeFile)
    {
        //exec("shp2pgsql -s $srid -d -g $geomColumnName $shapeFile $tableName");
        exec("shp2pgsql -s $srid -c -g $geomColumnName $shapeFile $tableName");
    }

    public function getDefaultMessage($status, $data, $message)
    {
        return new MTDefaultResponse($status, $data, $message);
    }

}