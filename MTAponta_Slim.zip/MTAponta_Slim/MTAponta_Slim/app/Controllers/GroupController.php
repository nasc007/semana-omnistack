<?php
namespace App\Controllers;

use App\Controllers\Controller;
use App\Models\Group;
use Respect\Validation\Validator as v;

class GroupController extends Controller
{
	public function index($request, $response){
		$groups= Group::all();
		return $this->view->render($response, 'views/group/index.twig', ['groups'=>$groups]);
	}

	public function add($request, $response){
		return $this->view->render($response, 'views/group/add.twig');
	}

	public function insert($request, $response){

		$validation = $this->validator->validate($request, [
			'name' => v::notEmpty(),
			'initial' => v::notEmpty(),
			'final' => v::notEmpty()
		]);

		if($validation->failed()){
			return $response->withRedirect($this->router->pathFor('group.add'));
		}

		$group = Group::create([
			'name' => $request->getParam('name'),
			'initial' => $request->getParam('initial'),
			'final' => $request->getParam('final')
		]);
		
		$this->flash->addMessage('info', 'Grupo incluído.');

		return $response->withRedirect($this->router->pathFor('group.index'));
	}

	public function edit($request, $response, $args){
		$group = Group::find($args['id']);
		return $this->view->render($response, 'views/group/edit.twig', ['group'=>$group]);
	}

	public function update($request, $response, $args){
		$group = Group::find($args['id']);
		if(!isset($group))
		{

			$this->flash->addMessage('danger', 'Problemas com a alteração.');

			return $response->withRedirect($this->router->pathFor('group.index'));
		}

		$validation = $this->validator->validate($request, [
			'name' => v::notEmpty(),
			'initial' => v::notEmpty(),
			'final' => v::notEmpty()
		]);

		if($validation->failed()){
			return $response->withRedirect($this->router->pathFor('group.edit',['id'=>$group->id]));
		}

		$group->name = $request->getParam('name');
		$group->initial = $request->getParam('initial');
		$group->final = $request->getParam('final');

		$group->save();

		$this->flash->addMessage('info', 'Grupo alterado.');

		return $response->withRedirect($this->router->pathFor('group.index'));
	}
}