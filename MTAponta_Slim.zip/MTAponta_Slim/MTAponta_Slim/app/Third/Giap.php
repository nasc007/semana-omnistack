<?php

namespace App\Third;

class Giap{

	static protected function login(){
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => "http://webservice.giap.com.br/mssirfpma/api/v1/validausuario",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => "{\"nomLogin\":\"usuario\",\"senhaUsuario\":\"senha\"}",
			CURLOPT_HTTPHEADER => array(
				"authorization: Bearer ".Giap::getAccessToken(),
				"content-type: application/json",
				"Accept: application/json"
				),
			)
		);

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if ($err) {
			throw new Exception("CURL error:". $err);
		} else {
			return $response;
		}		
	}

	static protected function getAccessToken(){
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => "https://www.ebisu.com.br/auth/jwt/token",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => "{\"user_id\":\"tecnosig.pma\",\"secret_id\":\"tecpma2019\",\"sessionTime\":\"3600\"}\n",
			CURLOPT_HTTPHEADER => array( "cache-control: no-cache", "content-type: application/json"),
			)
		);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			$retValue = json_decode( $response );
			return $retValue->access_token;
		}
		return '';
	}

	static public function getLogradouro($id)
	{
		//{"codLogradouro":"616","nomBairro":"PINHEIROS (JD)","nomLogradouro":"SÃO JOÃO","tipLogradouro":"AV"}
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => "http://webservice.giap.com.br/mssirfpma/api/v1/buscalogradouro/".$id,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
				"Authorization: Bearer ".Giap::getAccessToken(),
				"Content-Type: application/json",
				"Accept: application/json"
			),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			throw new Exception("CURL error:". $err);
		} else {
			return $response;
		}
	}

	static public function getInscricao($inscricao){
		//{"cep":"14811620","cidade":"ARARAQUARA","complemento":"RESIDENCIAL ALTOS DE PINHEIROS - III","estado":"SP","logradouro":{"codLogradouro":"766","nomBairro":"ALTOS DE PINHEIROS (JD)","nomLogradouro":"GASPAR PIEROBON","tipLogradouro":"AV"},"nomResponsavel":"FUNDO DE ARRENDAMENTO RESIDENCIAL - FAR","numInscricao":"25.200.021.00","numero":"605"}
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://webservice.giap.com.br/mssirfpma/api/v1/buscainscricao/".$inscricao,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
				"Authorization: Bearer ".Giap::getAccessToken(),
				"Content-Type: application/json",
				"Accept: application/json"
			),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if ($err) {
			throw new Exception("CURL error:". $err);
		} else {
			return $response;
		}
	}

	static public function geraInfracao($inscricao)
	{
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => "http://webservice.giap.com.br/mssirfpma/api/v1/geraInfracao",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => Giap::montaInfracao($inscricao),
			CURLOPT_HTTPHEADER => array(
				"authorization: Bearer ".Giap::getAccessToken(),
				"content-type: application/json",
				"Accept: application/json"
			),
			)
		);

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if ($err) {
			throw new Exception("CURL error:". $err);
		} else {
			return $response;
		}		
	}
	
	static protected function montaInfracao($inscricao)
	{
		return "{
			\"numInscricao\": \"".$inscricao."\",
			\"desImagens\": [
				{\"desImagem\": \"\"},/
				{\"desImagem\":\"\"}
			]
		}";
	}
}