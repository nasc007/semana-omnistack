<?php

namespace App\Middleware;

use \Firebase\JWT\JWT;
use \Firebase\JWT\ExpiredException;
use \DomainException;
use App\Models\User;
use App\Controllers\MTDefaultResponse;

class AuthApiMiddleware extends Middleware
{    
	public function __invoke($request, $response, $next){
        try {
            $token = $request->getParam('token');
            if(!$token)
                throw new \Exception('Invalid token');

            $decoded = JWT::decode($token, $this->container['settings']['security']['secret_key'], array('HS256'));
            if ($decoded) {
                $user = User::find($decoded->data->id);	
                if(!$user)
                    throw new \Exception("Invalid User");
                
                $_SESSION['authenticated_user'] = $user;
            }
        }
        catch ( DomainException | \Exception | ExpiredException $e) {
			return $response->withJson(new MTDefaultResponse("error", null, $e->getMessage()));
        }
        
		$response = $next($request, $response);
		return  $response;
	}
}