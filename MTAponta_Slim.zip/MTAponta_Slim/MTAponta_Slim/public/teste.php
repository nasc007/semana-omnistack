<?php
echo 'oi';	
echo phpinfo();
