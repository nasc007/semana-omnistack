<?php
// Routes

use App\Middleware\AuthMiddleware;
use App\Middleware\GuestMiddleware;
use App\Middleware\AuthApiMiddleware;

$app->get('/', 'HomeController:index')->setName('home')->add(new AuthMiddleware($container));

$app->group('', function(){
	$this->get('/auth/signin','AuthController:getSignIn')->setName('auth.signin');
	$this->post('/auth/signin','AuthController:postSignIn');
	$this->get('/auth/signup','AuthController:getSignUp')->setName('auth.signup');
	$this->post('/auth/signup','AuthController:postSignUp');
	$this->get('/teste','TestController:index');
})->add(new GuestMiddleware($container));

$app->post('/lote', 'GeoJsonController:lote');
$app->get('/ocorrenciasmapa', 'GeoJsonController:consultaOcorrenciasMapa');
$app->get('/centro', 'GeoJsonController:centro');
$app->get('/logradouro', 'LogradouroController:logradouro_mvt')->setName('logradouro');
$app->group('', function(){
	$this->get('/lote', 'GeoJsonController:lote')->setName('lote');
	$this->post('/pesquisa', 'PesquisaController:pesquisa');
	$this->post('/pesquisaavancada', 'PesquisaController:pesquisa_avancada');
	$this->get('/pesquisarapida/{inscricao}', 'PesquisaController:pesquisarapida');
	//$app->post('/ocorrencia', 'OcorrenciaController:ocorrencia');
	$this->get('/ocorrencia/{inscricao}', 'OcorrenciaController:get_ocorrencia');
	$this->get('/ocorrencia/{inscricao}/{cod_ocorrencia}', 'OcorrenciaController:get_ocorrencia_tipo');
	$this->post('/ocorrencia/{id}', 'OcorrenciaController:update');
	$this->get('/download/{filename}', 'OcorrenciaController:downloadPhotos');
	$this->get('/delete/{filename}', 'OcorrenciaController:deletePhotos');
	$this->get('/tipoOcorrenciacolor', 'OcorrenciaController:tipoOcorrencia');
	$this->post('/uploading', 'ShapeController:uploading');
	$this->get('/usuario/{nome}/{email}', 'UserController:pesquisa');
	$this->get('/tipoocorrencia', 'TipoOcorrenciaController:index');
	//$app->get('/ocorrenciatipo/{inscricao}', 'OcorrenciaController:ocorrenciaTipo');
	$this->post('/tipoocorrencia', 'TipoOcorrenciaController:add');
	$this->get('/deletetipoocorrencia/{id}', 'TipoOcorrenciaController:delete');
	$this->post('/updatetipoocorrencia/{id}', 'TipoOcorrenciaController:update');
	$this->get('/ocorrenciaagente', 'OcorrenciaController:ocorrenciaAgente');
	
})->add(new AuthMiddleware($container));

$app->group('/auth', function(){
	$this->get('/signout','AuthController:getSignOut')->setName('auth.signout');
})->add(new AuthMiddleware($container));

$app->group('/user', function(){
	$this->get('/','UserController:index')->setName('user.index');
	$this->get('/add','UserController:add')->setName('user.add');
	$this->post('/add','UserController:insert');
	$this->get('/edit/{id}','UserController:edit')->setName('user.edit');
	$this->get('/all', 'UserController:all');
	$this->get('/allgiap', 'UserController:UserGiap_all');
	$this->post('/status', 'UserController:alteraStatus');
	$this->post('/edit/{id}','UserController:update');
})->add(new AuthMiddleware($container));

$app->group('/api', function() {
	$this->group('/user', function(){
		$this->post('/create', 'UsuarioApiController:create');
		$this->post('/login', 'UsuarioApiController:login');
		$this->post('/pass', 'UsuarioApiController:pass')->add(new AuthApiMiddleware($this->getContainer()));
		$this->post('/location', 'UsuarioApiController:location')->add(new AuthApiMiddleware($this->getContainer()));
	});
	$this->group('/ocorrencia', function(){
		$this->post('/create', 'OcorrenciaController:create');
		$this->get('/tipo', 'TipoOcorrenciaController:index');
		$this->get('/tipo/{inscricao}', 'OcorrenciaController:ocorrenciaTipo');
		$this->get('/download/{filename}', 'OcorrenciaController:downloadPhotos');
		$this->post('/pesquisa', 'PesquisaController:pesquisa');
		$this->post('/update/{id}', 'OcorrenciaController:update');
		$this->get('/{inscricao}', 'OcorrenciaController:get_ocorrencia');
		$this->get('/{inscricao}/{cod_ocorrencia}', 'OcorrenciaController:get_ocorrencia_tipo');
	})->add(new AuthApiMiddleware($this->getContainer()));
});

