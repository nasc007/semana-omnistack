<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserGiap extends Model
{
	protected $table = 'user_giap';

	protected $primaryKey = 'login';
	
	protected $fillable = [
		'login',
		'name',
		'vlr_pos_x',
		'vlr_pos_y'
	];

	public $timestamps = false;

	public $incrementing = false;
}