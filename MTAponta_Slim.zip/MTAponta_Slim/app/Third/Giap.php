<?php

namespace App\Third;

class Giap{
	//return string nome usuario
	static public function login($ws_url, $user, $pass){
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $ws_url."/api/v1/validausuario",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => "{\"nomLogin\":\"$user\",\"senhaUsuario\":\"$pass\"}",
			CURLOPT_HTTPHEADER => array(
				"authorization: Bearer ".Giap::getAccessToken(),
				"content-type: application/json",
				"Accept: application/json"
				),
			)
		);

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);

		if ($err) {
			throw new \Exception("CURL error:". $err);
		} else {
			$data = json_decode($response);
			if($data->codigo == 200)
				return $data->nomUsuario;
			
			throw new \Exception("Error: ".$data->codigo." - ".$data->mensagem);
		}		
	}

	static protected function getAccessToken(){
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => "http://jwt.net.br/auth/jwt/token",//"https://www.ebisu.com.br/auth/jwt/token",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => "{\"user_id\":\"tecnosig.pma\",\"secret_id\":\"tecpma2019\",\"sessionTime\":\"3600\"}\n",
			CURLOPT_HTTPHEADER => array( "cache-control: no-cache", "content-type: application/json"),
			)
		);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			$retValue = json_decode( $response );
			return $retValue->access_token;
		}
		return '';
	}

	static public function getLogradouro($ws_url, $id)
	{
		//{"codLogradouro":"616","nomBairro":"PINHEIROS (JD)","nomLogradouro":"SÃO JOÃO","tipLogradouro":"AV"}
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => $ws_url."/api/v1/buscalogradouro/".$id,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
				"Authorization: Bearer ".Giap::getAccessToken(),
				"Content-Type: application/json",
				"Accept: application/json"
			),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			throw new \Exception("CURL error:". $err);
		} else {
			if(strlen($response) <= 2) 
				throw new \Exception("Logradouro não encontrado");

			return $response;
		}
	}

	static public function getInscricao($ws_url, $inscricao){
		//{"cep":"14811620","cidade":"ARARAQUARA","complemento":"RESIDENCIAL ALTOS DE PINHEIROS - III","estado":"SP","logradouro":{"codLogradouro":"766","nomBairro":"ALTOS DE PINHEIROS (JD)","nomLogradouro":"GASPAR PIEROBON","tipLogradouro":"AV"},"nomResponsavel":"FUNDO DE ARRENDAMENTO RESIDENCIAL - FAR","numInscricao":"25.200.021.00","numero":"605"}
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => $ws_url."/api/v1/buscainscricao/".$inscricao,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
				"Authorization: Bearer ".Giap::getAccessToken(),
				"Content-Type: application/json",
				"Accept: application/json"
			),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		//echo $response;
		if ($err) {
			throw new \Exception("CURL error:". $err);
		} else {
			return $response;
		}
	}

	static public function geraInfracao($upload_path, $ws_url, $inscricao, $ocorrencia_id, $nomLogin)
	{
		//echo json_encode(Giap::montaInfracao($upload_path, $inscricao, $ocorrencia_id, $nomLogin));die;
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $ws_url."/api/v1/geraInfracao",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => json_encode(Giap::montaInfracao($upload_path, $inscricao, $ocorrencia_id, $nomLogin)),
			CURLOPT_HTTPHEADER => array(
				"authorization: Bearer ".Giap::getAccessToken(),
				"content-type: application/json",
				"Accept: application/json"
			),
			)
		);

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
			throw new \Exception("CURL error:". $err);
		} else {
			/*
			{
				"codMensagem": 200,
				"desMensagem": "Gerada Infracao: 85"
			}
			*/
			$retValue = json_decode( $response );
			if($retValue->codMensagem == 200){
				if(strstr($retValue->desMensagem,"Gerada Infracao: ")){
					return intval(trim($retValue->desMensagem,"Gerada Infracao: "));
				}
			}
			else {
				throw new \Exception("Erro:". $retValue->desMensagem);
			}
		}
		return -1;		
	}
	
	static public function buscaImagens($upload_path,$dsc_inscricao,$cod_ocorrencia)
    {
        $files = [];

        $fileName = "IMG_".$dsc_inscricao."_".$cod_ocorrencia."_*.*";
        $directory = $upload_path;
        foreach (glob($directory.DIRECTORY_SEPARATOR.$fileName) as $arquivo){
            $files[] = basename($arquivo);
        }
        return $files;
	}
	
	static protected function montaInfracao($upload_path, $inscricao, $ocorrencia_id, $nomeLogin)
	{
		$images = Giap::buscaImagens($upload_path, $inscricao,$ocorrencia_id);
		
		$ret->numInscricao = $inscricao;
		$ret->nomLogin = $nomeLogin;
		$ret->desImagens = [];
		foreach($images as $imagePath){
        	$img = file_get_contents( $upload_path . DIRECTORY_SEPARATOR . $imagePath);
			$ret->desImagens[] = array("desImagem"=>base64_encode($img));
		}
		return $ret;
	}
}