<?php

namespace App\Controllers;

use App\Controllers\Controller;
use App\Models\Ocorrencia;
use Slim\Http\Request;
use Respect\Validation\EmailAvailable;
use Respect\Validation\Validator as v;
use App\Third\Giap;

class OcorrenciaController extends Controller
{
    public function create($request, $response, $args)
    {
        try {

		    $nomLogin = $_SESSION['authenticated_user']->login;
		    if(!$nomLogin)
                throw new \Exception("Sem usuário logado ou token inválido");
            
            $ocorrencia = Ocorrencia::create(array(
                'cod_tipo_ocorrencia' => $request->getParam('cod_tipo_ocorrencia'),//integer
                'cod_agente' => $request->getParam('cod_agente'),//integer
                'nomLoginGiap' => $nomLogin,
                'dsc_inscricao' => $request->getParam('dsc_inscricao'),//char
                'vlr_pos_x' => $request->getParam('vlr_pos_x'),//double
                'vlr_pos_y' => $request->getParam('vlr_pos_y'),//double
                'dat_ocorrencia' => $request->getParam('dat_ocorrencia'),//AAAA-MM-DD HH:MM:SS
                'nom_atendente' => $request->getParam('nom_atendente'),//char
                'tip_atendente' => $request->getParam('tip_atendente'),//integer
                'dsc_observacao' => $request->getParam('dsc_observacao'),//char
            ));
        
            $directory = $this->settings['upload_path'];
            $uploadedFiles = $request->getUploadedFiles();
            //var_dump($uploadedFiles);die;
            // handle single input with single file upload
            foreach ($uploadedFiles['file'] as $uploadedFile) {
                if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                    $this->moveUploadedFile($directory, $uploadedFile, $ocorrencia->cod_ocorrencia)."\r\n";
                }else {
                    throw new \Exception("CURL error:". $err);
                }
            }
            
            $codInfracao = giap::geraInfracao( $this->settings['upload_path'], $this->settings['giap']['ws_url'],$ocorrencia->dsc_inscricao, $ocorrencia->cod_ocorrencia, $nomLogin);
            if($codInfracao>0)
            {
                $ocorrencia->status = $codInfracao;
                $ocorrencia->save();
            }
            
            return $response->withJson($this->getDefaultMessage("ok", $ocorrencia, " Incluído com sucesso."));
        } catch(PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    public function update($request, $response, $args)
    {
        try {
            $ocorrencia = Ocorrencia::find($args['id']);
            if(!$ocorrencia){
                throw new \Exception("Ocorrência não encontrada");
            }

            $nomLogin = $_SESSION['authenticated_user']->login;
		    if(!$nomLogin)
                throw new \Exception("Sem usuário logado ou token inválido");
            
            $ocorrencia->cod_tipo_ocorrencia = $request->getParam('cod_tipo_ocorrencia');
            $ocorrencia->nomLoginGiap = $nomLogin;
            $ocorrencia->cod_agente = $request->getParam('cod_agente');
            $ocorrencia->dsc_inscricao = $request->getParam('dsc_inscricao');
            $ocorrencia->vlr_pos_x = $request->getParam('vlr_pos_x');
            $ocorrencia->vlr_pos_y = $request->getParam('vlr_pos_y');
            $ocorrencia->dat_ocorrencia = $request->getParam('dat_ocorrencia');
            $ocorrencia->nom_atendente = $request->getParam('nom_atendente');
            $ocorrencia->tip_atendente = $request->getParam('tip_atendente');
            $ocorrencia->dsc_observacao = $request->getParam('dsc_observacao');

            $ocorrencia->save();
            
            $directory = $this->settings['upload_path'];
            $uploadedFiles = $request->getUploadedFiles();
        
            foreach ($uploadedFiles['file'] as $uploadedFile) {
                if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                    $this->moveUploadedFile($directory, $uploadedFile)."\r\n";
                }else {
                    throw new \Exception("CURL error:". $err);
                }
            }
            return $response->withJson($this->getDefaultMessage("ok", null, "Alterado com sucesso."));
        } catch(PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }    
  

    public function moveUploadedFile($directory, $uploadedFile, $ocorrencia_id)
    { 
        try{
            $pos = strpos($uploadedFile->getClientFilename(), '_', strpos($uploadedFile->getClientFilename(), '_') + 1);
            $teste = substr_replace($uploadedFile->getClientFilename(),$ocorrencia_id,$pos+1,0);
            $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $teste);
            
            return $directory . DIRECTORY_SEPARATOR . $uploadedFile->getClientFilename();
        } catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }
 

    public function get_ocorrencia($request, $response, $args)
    {
        try{
            $sth = $this->pdo->prepare("SELECT *, 'Agente Cadastrado' as nome_agente, (SELECT T.nome FROM tipo_ocorrencia T WHERE T.id = O.cod_tipo_ocorrencia LIMIT 1) 
                                                    as dsc_ocorrencia FROM mt_ocorrencias O WHERE O.dsc_inscricao = '".$args['inscricao']."' ORDER BY cod_ocorrencia DESC");
            $sth->execute();
            $retorno = $sth->fetchALL();
            $retVal=[];
            foreach ($retorno as $row) {
                $row['fotos'] = $this->getFotos($row["dsc_inscricao"],$row["cod_ocorrencia"],$row["data"]);
                $retVal[] = $row;
            }
            return $this->response->withJson($retVal);
        } catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }   

    public function get_ocorrencia_tipo($request, $response, $args)
    {
        try{
            $sth = $this->pdo->prepare("SELECT * FROM mt_ocorrencias WHERE dsc_inscricao = '".$args['inscricao']."' AND cod_ocorrencia = '".$args['cod_ocorrencia']."'");
            $sth->execute();
            $retorno = $sth->fetchALL();
            $retVal=[];
            foreach ($retorno as $row) {
                $row['fotos'] = $this->getFotos($row["dsc_inscricao"],$row["cod_ocorrencia"],$row["data"]);
                $retVal[] = $row;
            }
        
            return $this->response->withJson($retVal);
        }
        catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }  

    public function getFotos($dsc_inscricao,$cod_ocorrencia,$data)
    {
        try{
            $files = [];

            $fileName = "IMG_".$dsc_inscricao."_".$cod_ocorrencia."_*.*";
            $directory = $this->settings['upload_path'];
            foreach (glob($directory.DIRECTORY_SEPARATOR.$fileName) as $arquivo){
                $files[] = basename($arquivo);
            }
            
            return $files;
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    public function downloadPhotos($request, $response, $args)
    {
        try{
            $directory = $this->settings['upload_path'];
            $file = $directory . DIRECTORY_SEPARATOR . $args['filename'];
            $fh = fopen($file, 'rb');
            $stream = new \Slim\Http\Stream($fh); // create a stream instance for the response body   
            return $response->withHeader('Content-Type', 'application/force-download')
                            ->withHeader('Content-Type', 'application/octet-stream')
                            ->withHeader('Content-Type', 'application/download')
                            ->withHeader('Content-Description', 'File Transfer')
                            ->withHeader('Content-Transfer-Encoding', 'binary')
                            ->withHeader('Content-Disposition', 'attachment; filename="' . basename($file) . '"')
                            ->withHeader('Expires', '0')
                            ->withHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0')
                            ->withHeader('Pragma', 'public')
                            ->withBody($stream);
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    public function deletePhotos($request, $response, $args)
    {
        try {
            $directory = $this->settings['upload_path'];
            $file = $directory . DIRECTORY_SEPARATOR . $args['filename'];
            unlink ($file);

            return $response->withJson($this->getDefaultMessage("ok", null, "Excluido com sucesso."));
        } catch (PDOException | \Exception $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
        
    }

    public function ocorrenciaTipo($request, $response, $args)
    {
        try {
            $ocorrencia = '';
            $sth = $this->pdo->prepare("SELECT A.cod_ocorrencia, A.dat_ocorrencia, 'Agente Cadastrado' as agente,
            A.dsc_inscricao,
            (SELECT B.nome FROM tipo_ocorrencia B WHERE B.id = A.cod_tipo_ocorrencia)
                            FROM mt_ocorrencias A WHERE A.dsc_inscricao = '".$args['inscricao']."' ORDER BY cod_ocorrencia DESC");
            $sth->execute();
            $retorno = $sth->fetchALL();
            $retVal=[];
            foreach ($retorno as $row) {
                $row['fotos'] = $this->getFotos($row["dsc_inscricao"],$row["cod_ocorrencia"],$row["data"]);
                $retVal[] = $row;
            }

            return $this->response->withJson($retVal);
        } catch (PDOException | \Exception $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
        
    }

    public function ocorrenciaAgente($request, $response, $args)
    {
        try{
            $sql = "SELECT cod_ocorrencia, (SELECT nome FROM tipo_ocorrencia b WHERE a.cod_tipo_ocorrencia = b.id) 
                as ocorrencia, dsc_inscricao, dat_ocorrencia, nom_atendente, dsc_observacao, vlr_pos_x, vlr_pos_y 
                FROM mt_ocorrencias a ";
            if($request->getParam('insc') || $request->getParam('agente') || $request->getParam('dataIni') )
                $sql .= " WHERE ";
        
            $where = '';
            if($request->getParam('insc'))
            {
                $where .= " dsc_inscricao ILIKE '%".$request->getParam('insc')."%' ";
            }
            if($request->getParam('agente'))
            {
                if($where != '')
                {
                    $where.= " OR ";
                }
                $where .= " nom_login_giap ILIKE '%".$request->getParam('agente')."%' ";
            }
            if($request->getParam('dataIni'))
            {
                if($where != '')
                {
                    $where.= " AND ";
                }
                $where .= " dat_ocorrencia >= ".$request->getParam('dataIni')." ";
                if($request->getParam('dataFimm'))
                {
                    $where.=" AND dat_ocorrencia <= " . $request->getParam('dataFimm');
                }
            }

            $where .= "ORDER BY cod_ocorrencia";
            $sql .= $where."";
            
            $sth = $this->pdo->prepare($sql); 
                     
            $sth->execute();
            $retorno = $sth->fetchALL();
            
            return $this->response->withJson($retorno);
        }catch (PDOException | \Exception $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    public function tipoOcorrencia($request, $response, $args)
    {
        try{
            $sth = $this->pdo->prepare("SELECT * FROM public.tipo_ocorrencia ORDER BY id");
            $sth->execute();
            $retorno = $sth->fetchALL();

            return $this->response->withJson($retorno);
        }catch (PDOException | \Exception $e) {
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }
}

/*
SELECT cod_ocorrencia, (SELECT nome FROM tipo_ocorrencia b WHERE a.cod_tipo_ocorrencia = b.id) 
                as ocorrencia, dsc_inscricao, dat_ocorrencia, nom_atendente, dsc_observacao, vlr_pos_x, vlr_pos_y
                    FROM mt_ocorrencias a
                    WHERE nom_login_giap = 'TESTE' AND dat_ocorrencia = (CURRENT_DATE-9) ORDER BY cod_ocorrencia

SELECT array_to_json(array_agg(row_to_json(t)))
                FROM (SELECT * FROM mt_ocorrencias WHERE nom_login_giap = 'TESTE')t

SELECT cod_ocorrencia, cod_tipo_ocorrencia, dsc_inscricao, dat_ocorrencia, nom_atendente, dsc_observacao
            FROM mt_ocorrencias 
            WHERE nom_login_giap = '".$args['agente']."' AND dat_ocorrencia = (CURRENT_DATE-8)
*/