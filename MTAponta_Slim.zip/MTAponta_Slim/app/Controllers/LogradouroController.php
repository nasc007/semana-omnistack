<?php

namespace App\Controllers;

use App\Controllers\Controller;

class LogradouroController extends Controller
{
    public function logradouro($request, $response, $args)
    {
        try{
            $tile = '';
            $sth = $this->pdo->prepare(
                "SELECT row_to_json(fc)
                FROM ( SELECT 'FeatureCollection' As type, array_to_json(array_agg(f)) As features
                FROM (SELECT 'Feature' As type
                , ST_AsGeoJSON(lg.geom)::json As geometry
                , row_to_json((codeixo, denominaca)) As properties
                FROM eixos As lg   ) As f )  As fc;");

            $sth->execute();
            $tile = $sth->fetchALL();
            
            return $response->withAddedHeader('Access-Control-Allow-Origin', '*')->withJson($tile[0]);
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    public function logradouro_mvt($request, $response)
    {
        try{
            $response->getBody()->write($this->get_tile($_GET['z'],$_GET['x'],$_GET['y']));
            
            $response = $response->withAddedHeader('Access-Control-Allow-Origin', '*');
            $response = $response->withAddedHeader('Cache-Control', 'max-age=8460000');
            return $response;
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    
    function tile_ul($x, $y, $z)
    {
        try{
            $n = 2.0 ** $z;
            $lon_deg = $x / $n * 360.0 - 180.0;
            $lat_rad = atan(sinh(pi() * (1 - 2 * $y / $n)));
            $lat_deg = rad2deg($lat_rad);
            return  [$lon_deg,$lat_deg];
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }

    function get_tile($z,$x,$y)
    {
        try{        
            $minPt= $this->tile_ul($x, $y, $z);
            $xmin = $minPt[0];
            $ymin = $minPt[1];
            
            $maxPt= $this->tile_ul($x + 1, $y + 1, $z);
            $xmax = $maxPt[0];
            $ymax = $maxPt[1];
            

            $tile = null;
            $pdo = $this->pdo;
            $query = "SELECT ST_AsMVT(tile) FROM (SELECT codeixo, denominaca , angle, ST_AsMVTGeom(shape, 
            st_transform(ST_SetSrid(ST_Makebox2d(ST_MakePoint($xmin,$ymin),ST_MakePoint($xmax, $ymax)),4326),3857), 4096, 0, false) AS geom FROM 
                (SELECT  codeixo, denominaca, st_azimuth(st_startpoint(geom),st_endpoint(geom)) as angle, st_transform(geom,3857) as shape FROM eixos where st_transform(geom,4326)  && ST_SetSrid(ST_ENVELOPE('LINESTRING($xmin $ymin, $xmax $ymax)'::geometry),4326)) as qbounds) AS tile";

            //echo ($query); die;
            $stmt = $pdo->query($query);
            if(!$stmt)
                die("Execute query error, because: ". print_r($pdo->errorInfo(),true) );
            
            while ($row = $stmt->fetch())
            {
                $tile = stream_get_contents($row['st_asmvt']);
            }

            return $tile;
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }
}

