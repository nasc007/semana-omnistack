<?php
namespace App\Controllers;

use App\Controllers\Controller;
use App\Models\User;
use App\Models\UserGiap;
use Respect\Validation\EmailAvailable;
use Respect\Validation\Validator as v;
use \Firebase\JWT\JWT;
use \Firebase\JWT\ExpiredException;

class UserController extends Controller
{
	public function index($request, $response)
	{
		$users= User::all();
		return $this->view->render($response, 'views/user/index.twig', ['users'=>$users]);
	}
	
	public function add($request, $response){
		return $this->view->render($response, 'views/user/add.twig');
	}

	public function insert($request, $response)
	{

		$validation = $this->validator->validate($request, [
			'email' => v::noWhitespace()->notEmpty()->emailAvailable(),
			'name' => v::noWhitespace()->notEmpty()->alpha(),
			'password' => v::noWhitespace()->notEmpty()
		]);

		if($validation->failed()){
			return $response->withRedirect($this->router->pathFor('user.add'));
		}

		$user = User::create([
			'email' => $request->getParam('email'),
			'name' => $request->getParam('name'),
			'password' => password_hash($request->getParam('password'), PASSWORD_DEFAULT),
		]);
		
		$this->flash->addMessage('info', 'Usuário incluído.');

		return $response->withRedirect($this->router->pathFor('user.index'));
	}

	public function edit($request, $response, $args)
	{
		$user = User::find($args['id']);
		return $this->view->render($response, 'views/user/edit.twig', ['user'=>$user]);
	}

	public function update($request, $response, $args)
	{
		$user = User::find($args['id']);
		if(!isset($user))
		{

			$this->flash->addMessage('danger', 'Problemas com a alteração.');

			return $response->withRedirect($this->router->pathFor('user.index'));
		}

		$validation = $this->validator->validate($request, [
			'email' => v::noWhitespace()->notEmpty(),
			'name' => v::noWhitespace()->notEmpty()->alpha(),
			'password' => v::noWhitespace()->notEmpty()
		]);

		if($validation->failed()){
			return $response->withRedirect($this->router->pathFor('user.edit',['id'=>$user->id]));
		}

		$user->email = $request->getParam('email');
		$user->name = $request->getParam('name');
		$user->password = password_hash($request->getParam('password'), PASSWORD_DEFAULT);

		$user->save();

		$this->flash->addMessage('info', 'Usuário alterado.');

		return $response->withRedirect($this->router->pathFor('user.index'));
	}

	public function pesquisa($request, $response, $args)
	{
        $sth = $this->pdo->prepare("SELECT * FROM usuario WHERE nome = '".$args['nome']."' AND email = '".$args['email']."'");
        $sth->execute();
        $retorno = $sth->fetchALL();
        
        //var_dump($retorno); die;
        return $this->response->withJson($retorno);
	}
	
	public function all($request, $response, $args)
	{
		try {
			//$user = User::Raw('st_asgeojson(localizacao)')->orderBy('id')->get();
			$user = User::orderBy('id')->get();
			return $response->withJson($this->getDefaultMessage("ok", $user, ""));
		}catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }
	}

	public function UserGiap_all($request, $response, $args)
	{
		try {
			$user_giap = UserGiap::orderBy('name')->get();
			return $response->withJson($this->getDefaultMessage("ok", $user_giap, ""));
		}catch (\PDOException | \Exception $e) {
			return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
		}
	}

	public function alteraStatus($request, $response, $args)
	{
		try {
			$id = $request->getParam('user_id');
			$user = User::find($id);
			//var_dump($user);die;
			$user->ativo = !$user->ativo;

			$user->save();
			return $response->withJson($this->getDefaultMessage("ok", $user, " Atualizado com sucesso!"));
		}catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }
	}
	
}