<?php

namespace App\Controllers;

use App\Controllers\Controller;
use Slim\Http\Request;

class TipoOcorrenciaController extends Controller
{
    public function index($request, $response, $args){
        try{
            $sth = $this->pdo->prepare("SELECT * FROM tipo_ocorrencia");
            $sth->execute();
            $retorno = $sth->fetchALL();
            
            //var_dump($retorno); die;
            return $this->response->withJson($retorno);
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }
    }

    public function add($request, $response, $args){
        try {
            $tipoOcorrencia = '';
            $sth = $this->pdo->prepare("INSERT INTO public.tipo_ocorrencia VALUES(DEFAULT, :nome, :color)RETURNING id");
            
            $sth->execute(array(
                'nome' => $request->getParam('nome'),
                'color' => $request->getParam('color'),
            ));
            
            $tipoOcorrencia = $sth->fetchALL();
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }
    }

    public function update($request, $response, $args){
        try {
            $tipoOcorrencia = '';
            $sth = $this->pdo->prepare("UPDATE public.tipo_ocorrencia SET(nome = :nome) WHERE id = ".$args['id']."");
            
            $sth->execute(array(
                'nome' => $request->getParam('nome'),
            ));
            
            $tipoOcorrencia = $sth->fetchALL();
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }
    }

    public function delete($request, $response, $args){
        try {
            $tipoOcorrencia = '';
            $sth = $this->pdo->prepare("DELETE FROM public.tipo_ocorrencia WHERE id = ".$args['id']."");
            
            $sth->execute();
            
            $tipoOcorrencia = $sth->fetchALL();
        }catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }
    }
}