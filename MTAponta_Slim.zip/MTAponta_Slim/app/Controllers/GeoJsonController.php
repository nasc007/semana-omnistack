<?php

namespace App\Controllers;

use App\Controllers\Controller;
use App\Third\Giap;

class GeoJsonController extends Controller
{
    public function lote($request, $response, $args)
    {
        try{
            $tile = '';
            $sth = $this->pdo->prepare("with outro as ( SELECT geom as shape, cod_ocorrencia, SUBSTRING(insclote,1,2) ||'.'||SUBSTRING(insclote,3,3) ||'.'||SUBSTRING(insclote,6,3) ||'.00' as inscricao from lotes 
            left join mt_ocorrencias m on m.dsc_inscricao = SUBSTRING(insclote,1,2) ||'.'||SUBSTRING(insclote,3,3) ||'.'||SUBSTRING(insclote,6,3) ||'.00' WHERE  st_contains(geom, st_transform(
            ST_SetSrid('POINT(".$request->getParam('lat').' '.$request->getParam('long').")'::geometry,3857),31982)) limit 1 ) 
            ( SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features from (
            select row_to_json(p) from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(shape,3857))::json AS geometry, row_to_json(
            row(inscricao, cod_ocorrencia)) as properties from outro)p)m)t)
            ");
            $sth->execute();
           
            $tile = $sth->fetchALL();
            $data = json_decode($tile[0]['coordenada']);

            if(!$data->features[0]->geometry)
                throw new \Exception("Inscrição não encontrada na coordenada.");
            
            $giap = Giap::getInscricao($this->settings['giap']['ws_url'], $data->features[0]->properties->f1);  
            
            $giap = json_decode($giap);
            $aux = $data->features[0]->properties->f2;
            $data->features[0]->properties->f2 = $giap->nomResponsavel;
            $data->features[0]->properties->f4 = $giap->logradouro->nomLogradouro;
            $data->features[0]->properties->f5 = $giap->numero;
            $data->features[0]->properties->f7 = $aux;

            return $response->withHeader('Access-Control-Allow-Origin', '*')
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
            ->withJson($data);
        } catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));

        }

        /* {"cep":"14801290","cidade":"ARARAQUARA","complemento":" ","estado":"SP",
            "logradouro":{"codLogradouro":"80","nomBairro":"CENTRO","nomLogradouro":"GON\u00c7ALVES DIAS","tipLogradouro":"R"},
            "nomResponsavel":"THEREZINHA MAZZEI BIZELLI E SM","numInscricao":"04.001.006.00","numero":"1197"}*/
    }

    public function centro($request, $response, $args)
    {
        try {
            $tile = '';
            $sth = $this->pdo->prepare("SELECT avg(st_x(geom)) as x, avg(st_y(geom)) as y from (select st_transform(st_centroid(st_collect(st_envelope(geom)))::geometry,3857) as geom from lotes)g
            ");
            try{
                $sth->execute();
            }catch(PDOException | \Exception $e){
                return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));    
            }
            $tile = $sth->fetch();
            $returnValue = [floatval($tile['x']),floatval($tile['y'])];
            
            return $response->withAddedHeader('Access-Control-Allow-Origin', '*')->withJson($returnValue);
        } catch(PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
        
    }

    public function consultaOcorrenciasMapa($request, $response, $args)
    {
        try {
            $sth = $this->pdo->prepare("with filtro as (SELECT count(cod_ocorrencia) contador, dsc_inscricao, cod_tipo_ocorrencia 
            FROM mt_ocorrencias a WHERE cod_tipo_ocorrencia = a.cod_tipo_ocorrencia group by dsc_inscricao, cod_tipo_ocorrencia 
            ORDER BY dsc_inscricao, cod_tipo_ocorrencia ), teste as (
                select f.*, l.* from filtro f left join lotes l on (l.insclote::text||'00') = REPLACE(f.dsc_inscricao,'.','')) (
                    SELECT row_to_json(t)as coordenada FROM (SELECT 'FeatureCollection' AS type,array_to_json(array_agg(row_to_json(m))) AS features from ( 
                        select row_to_json(p) from (select 'Feature' AS type, ST_AsGeoJSON(st_transform(geom,3857))::json AS geometry, row_to_json( 
                            row(contador,dsc_inscricao,cod_tipo_ocorrencia)) as properties from teste)p)m)t)
            ");
            try{
                $sth->execute();
            }catch(\PDOException | \Exception $e){
                return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));    
            }
            $tile = $sth->fetch();
            //var_dump($sth);die;
            $data = json_decode($tile['coordenada']);

            return $response->withHeader('Access-Control-Allow-Origin', '*')
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
            ->withJson($data);
        } catch(\PDOException | \Exception $e){
            return $response->withJson($this->getDefaultMessage("error", null, $e->getMessage()));
        }
    }
}