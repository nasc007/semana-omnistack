<?php
return [
    "settings" => [
        "displayErrorDetails" => true,
        "upload_path" => "/var/www/MTAponta_Slim/upload/",
        "upload_shape" => "/var/www/MTAponta_Slim/shape/",
        "license_key" => "a1322380-b7b9-4a5e-85d7-d53d797b8bfa",
        // Renderer settings
        "renderer" => [
            "template_path" => __DIR__ . "/../resources/",
        ],

        // Monolog settings
        "logger" => [
            "name" => "slim-app",
            "path" => __DIR__ . "/../logs/app.log",
        ],
        "db" => [
            "driver"   => "pgsql",
            //'host' => '192.168.0.100',
            "host" => "localhost",
            //'port' => '5435',
            "port" => "5432",
            "database" => "araraquara",
            "username" => "postgres",
            "password" => "postgres"
        ],
        "config" => [
            "bin-dir" => "vendor/bin/"
        ],
        "security" => [
            "secret_key" => "YOUR_SECRET_KEY",
            "issuer_claim" => "THE_ISSUER", // this can be the servername
            "audience_claim" => "THE_AUDIENCE"
        ],
        "shp2pgsql" => [
            "s" => "31982",
            "g" => "geom",
            "table" => "lotes1"
        ],
        "giap" => [
            "ws_url" => "http://webservice.giap.com.br/mssirfpma"
        ]
    ],
];