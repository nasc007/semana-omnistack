var centerer;// = ol.proj.transform([-48.2017747,-21.781757],//[-44.02884352, -19.92260823],//'EPSG:4326', 'EPSG:3857');

function getCorStroke(cod_tipo_ocorrencia) {
    switch (cod_tipo_ocorrencia) {
        case 1:
            return 'rgba(137,226,60)';//#89e23c
        case 2:
            return 'rgba(69,181,79)';//#45b54f
        case 3:
            return 'rgba(56,142,123)';//#388e7b
        case 4:
            return 'rgba(61,96,255)';//#3d60ff
        case 5:
            return 'rgba(116,65,255)';//#7441ff
        case 6:
            return 'rgba(122,31,159)';//#7a1f9f
        case 7:
            return 'rgba(171,49,169)';//#ab31a9
        case 8:
            return 'rgba(237,41,0)';//#ed2900
        case 9:
            return 'rgba(238,81,5)';//#ee5105
        case 10:
            return 'rgba(241,142,7)';//#f18e07
    }
    return 'rgba(200,200,0,1)';
}

function getCorFill(cod_tipo_ocorrencia) {
    switch (cod_tipo_ocorrencia) {
        case 1:
            return 'rgba(137,226,60,0.25)';//#89e23c
        case 2:
            return 'rgba(69,181,79,0.25)';//#45b54f
        case 3:
            return 'rgba(56,142,123,0.25)';//#388e7b
        case 4:
            return 'rgba(61,96,255,0.25)';//#3d60ff
        case 5:
            return 'rgba(116,65,255,0.25)';//#7441ff
        case 6:
            return 'rgba(122,31,159,0.25)';//#7a1f9f3
        case 7:
            return 'rgba(171,49,169,0.25)';//#ab31a9
        case 8:
            return 'rgba(237,41,0,0.25)';//#ed2900
        case 9:
            return 'rgba(238,81,5,0.25)';//#ee5105
        case 10:
            return 'rgba(241,142,7,0.25)';//#f18e07
    }
    return 'rgba(200,200,0,0.25)';
}

vectorSource =  new ol.source.Vector();
vectorTile =  new ol.source.Vector(); 
var loteVector = new ol.layer.Vector({
    source: vectorTile,
    style: function(feature, res) {
        let corStroke = getCorStroke(feature.values_["f3"]);
        let corFill = getCorFill(feature.values_["f3"]);
        return new ol.style.Style({
            stroke: new ol.style.Stroke({
                width: 2,
                color: corStroke
            }),
            fill: new ol.style.Stroke({
                width: 2,
                color: corFill
            })
        })
    }
});

vectorTilecolor =  new ol.source.Vector(); 
var colorVector = new ol.layer.Vector({
    source: vectorTilecolor,
    style: function(feature, res) {
        let corStroke = getCorStroke(feature.values_["f3"]);
        let corFill = getCorFill(feature.values_["f3"]);
        return new ol.style.Style({
            stroke: new ol.style.Stroke({
                width: 2,
                color: corStroke
            }),
            fill: new ol.style.Stroke({
                width: 2,
                color: corFill
            })
        })
    }
});

var mySource = new ol.source.VectorTile({
    format: new ol.format.MVT(),
    url: urlVia,
    crossOrigin: 'anonymous'
});

var via = new ol.layer.VectorTile({
    source: mySource,
    maxZoom: 20,
    minZoom: 18.50,
    style: function(feature) {
        return new ol.style.Style({
            text: new ol.style.Text({
                stroke: new ol.style.Stroke({
                    width: 1,
                    color: 'rgb(0, 0, 0)'
                }),
                fill: new ol.style.Fill({
                    color: 'rgb(255, 255, 255)'
                }),
                font:"bold 11px/1 Arial",
                placement:'line',
                maxAngle: 6.283185307179586,
                text: feature.get('denominaca')
            })
        });
    },
    minResolution: 0.01,
    maxResolution: 1
});

/***** Criando linha entre dois posntos ******/
function linha_reta(start, end) {
    
   // if(map.getLayers().getLength() > 5)
    //    map.removeLayer(map.getLayers().getArray()[map.getLayers().getLength()-1]);
        
    var sourceLinha = new ol.source.Vector();
    sourceLinha.addFeature(new ol.Feature({
        geometry : new ol.geom.LineString([start,end]),
        text : Math.floor(Math.sqrt((end[0]-start[0])*(end[0]-start[0])+(end[1]-start[1])*(end[1]-start[1])))
    }));

    var styleFunctionLinha = function(feature) {
        var geometry = feature.getGeometry();
        var styles = [
            // linestring
            new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: '#ffcc33',
                    width: 2
                }),
                text: new ol.style.Text({
                    stroke: new ol.style.Stroke({
                        width: 2,
                        color: 'rgb(0, 0, 0)'
                    }),
                    fill: new ol.style.Fill({
                        color: '#F4B813'
                    }),
                    font:"bold 20px/1 Arial",
                    placement:'line',
                    maxAngle: 6.283185307179586,
                    textBaseline: 'bottom',
                    text: feature.get('text').toString() + "m"
                })
            })
        ];

        geometry.forEachSegment(function(start, end) {
            var dx = end[0] - start[0];
            var dy = end[1] - start[1];
            var rotation = Math.atan2(dy, dx);
            // arrows
            styles.push(new ol.style.Style({
            geometry: new ol.geom.Point(end),
            image: new ol.style.Icon({
                src: 'img/arrow.png',
                anchor: [0.75, 0.5],
                rotateWithView: true,
                rotation: -rotation
            })
            }));
        });
        return styles;
    };

    vectorLinha = new ol.layer.Vector({
        source: sourceLinha,
        style: styleFunctionLinha
    });

    const extent = sourceLinha.getFeatures()[0].getGeometry().getExtent();
    extent[0] -= 100;
    extent[1] -= 100;
    extent[2] += 100;
    extent[3] += 100;

    map.getView().fit(extent);
    map.addLayer(vectorLinha);
    
}

var view = new ol.View({
    center: center,
    zoom: 18,
    maxZoom: 20,
    enableRotation: false,
})

var agentes =  new ol.layer.Vector({
    source: new ol.source.Vector(),
    style: new ol.style.Style({
        image: new ol.style.Icon({
          anchor: [0.5, 46],
          anchorXUnits: 'fraction',
          anchorYUnits: 'pixels',
          src: 'img/agente.png'
        })
    })
});

/***** Carregando o mapa ******/
var map = new ol.Map({
    layers: [
        new ol.layer.Tile({
            source: new ol.source.OSM(),
            maxZoom: 18.50,
            visible: false,
        }),
        new ol.layer.Tile({
            source: new ol.source.XYZ({
                url: urlOrtofoto,
            }),
            maxZoom: 20,
            minZoom: 18.50
        }),
        new ol.layer.Vector({
            source: vectorSource,
            visible: false,
            style: function(feature, res) {
                if(feature.get('dsc_layer') == 'LOTES_NOVOS')
                return new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        width: 2,
                        color: 'rgba(200, 200, 0)'
                    }),
                    fill: new ol.style.Stroke({
                        width: 2,
                        color: 'rgba(200, 200, 0, 0.25)'
                    })
                })
            }
        }),
        via,
        loteVector,
        colorVector,
        agentes,
        //vectorLinha
    ],
    target: "map",
    view: view
});
map.on('error', e => {
    $('#blabla').hide();
})
map.on('rendercomplete', e => {
    $('#blabla').hide();
})

var overlayAgentes = new ol.Overlay({
    element: document.getElementById('popupAgente'),
    offset: [0, -45] 
});
map.addOverlay(overlayAgentes);

/***** Evento click no mapa ******/
var onClick = function(event) {
    var feature = map.forEachFeatureAtPixel(event.pixel,
        function(feature) {
            return feature;
        });
    if (feature != null && feature.getGeometry().getType()=='Point') {
        var element = overlayAgentes.getElement();
        var coordinate = feature.getGeometry().getCoordinates();
        infoAgente(feature.get('name'))
        return;
    }


    //desmarcaLote();
    var request = new XMLHttpRequest();
    request.open('POST', '/lote', true);
    var formData = new FormData(); 
    loc_selecao = event.coordinate;
    formData.append("lat", event.coordinate[0]);
    formData.append( "long",event.coordinate[1]);
    request.responseType = 'json';    
    request.send(formData);
    
    request.onreadystatechange = function() {
        if (request.readyState == XMLHttpRequest.DONE) {
            var jsonResponse = request.response;
            var matches = request.response.status == "error"?desmarcaLote()&fechaModal('#modalInfo'):new ol.format.GeoJSON().readFeatures(request.response);
            incFoto = matches !== 0  ? matches[0].getProperties('f2') : undefined;
            if (!matches) {
                vectorTile.clear();
                return;
            }
            vectorTile.clear();
            vectorTile.addFeatures(matches); 
            loteVector.setStyle(loteVector.getStyle());
            document.getElementById('btnDados').setAttribute('class', "button btnViewdados fa-blink");
            dados = matches;
            infoLote(dados);
        }
    }
};

var popupAgente = function(event) {
    $('#popupAgente').popover('dispose');
    var feature = map.forEachFeatureAtPixel(event.pixel,
        function(feature) {
            return feature;
        });
    if (feature != null && feature.getGeometry().getType()=='Point') {
        var element = overlayAgentes.getElement();
        var coordinate = feature.getGeometry().getCoordinates();
        $(element).popover('dispose');
        overlayAgentes.setPosition(coordinate);
        $(element).popover({
            container: '#popupAgente',
            placement:'top',
            html:false,
            template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header" style="color:red"></h3><div class="popover-body"></div></div>',
            content:feature.get('name')?feature.get('name'):''
        });
        $(element).popover('show');
        return;
    }
}

map.on('pointermove', popupAgente);
map.on('click', onClick);
map.on('pointermove', function(evt) {
    if (evt.dragging) {
      $('#popup').popover('hide');
      return;
    }
});

function infoAgente(agente) {
    document.getElementById('btnDados').setAttribute('class', "button btnViewdados");
    abrirModal('#modal_info_agente');
    document.getElementById('home-tab-agente').setAttribute('class', "nav-link active");
    document.getElementById('profile-tab-agente').setAttribute('class', "nav-link");
    document.getElementById('info_agente').setAttribute('class', "tab-pane fade show active");
    document.getElementById('profile_agente').setAttribute('class', "tab-pane fade");
    var infoBox = document.getElementById('info_agente');
    infoBox.innerHTML = toInfoDivAgente(agente);
    ocorrenciaAgente(agente);
}

function ocorrenciaAgente(agente) {
    let data = '2020-03-03';//new Date().toJSON().slice(0,10).split('-').join('-');
    fetch("/ocorrenciaagente?"+'agente='+agente.trim()+'&'+'dataIni='+"\'"+data.toString()+"\'"+'&'+'dataFimm='+"\'"+data.toString()+"\'")
    .then(res => res.json())
    .then((out) => {
        var infoBox = document.getElementById('ocorrencias_agente_ul');
        while(infoBox.firstChild)
            infoBox.removeChild(infoBox.firstChild);

        for (let i = 0; i < out.length; i++) {
            let dataFormatada = out[i].dat_ocorrencia.replace(/(\d*)-(\d*)-(\d*).*/, '$3-$2-$1');
            let insc = out[i].dsc_inscricao.toString();
            let infoLi =  $('<li></li>');
            let btn = $("<button title='Centralizar Lote' style='position: absolute; right: 5px; top: -20px;'\
                            onclick='centralizaPesquisa("+'['+out[i].vlr_pos_x+','+out[i].vlr_pos_y+']'+','+null+','+"\""+out[i].dsc_inscricao+"\")' class='button'>\
                            <i class='fas fa-map-marked-alt'></i>\
                        </button>");
            let inscLi = $("<p>Ocorrencia: <strong>"+out[i].cod_ocorrencia+"</strong></p>");             
            let rowLi = $("<div class='row' style='max-width: 100%; margin-left: inherit;'></div>");
            let colOcorrencia = $("<div class='col 12' style=''></div>");
            
            colOcorrencia.append($("<div class='row'>\
                                        Descrição:&nbsp; <strong>"+out[i].ocorrencia+"</strong>\
                                    </div>\
                                    <div class='row'>\
                                        Data:&nbsp; <strong>"+dataFormatada+"</strong>&nbsp;&nbsp;\
                                    </div>\
                                    <div class='row'>\
                                        <div title='"+out[i].dsc_observacao+"'>\
                                            Observação:&nbsp; <strong>"+out[i].dsc_observacao+"</strong>&nbsp;&nbsp;\
                                        </div>\
                                    </div>"),btn);

            let linha = $("<hr width = '100%' size = '100' style='margin-top: 1rem;margin-bottom: 10px;'>");
            
            rowLi.append(colOcorrencia);
            infoLi.append(inscLi.append(rowLi));
            $('#ocorrencias_agente_ul').append(infoLi,linha);
        }
        
    })
    .catch((e)=> e)
}

function tipoOcorrenciacolor() {
    fetch("/tipoOcorrenciacolor")
    .then(res => res.json())
    .then((out) => {
        var infoBox = document.getElementById('nomecores');
        while(infoBox.firstChild)
            infoBox.removeChild(infoBox.firstChild);
        
        for (let i = 0; i < out.length; i++) {
            let color = out[i].color;
            let id = out[i].id;
            let name = out[i].nome;
            let div = $("<div></div>");

            div.append($("<div>\
                            <i class='fas fa-palette' style='color:"+color+"'></i>\
                            <label class='form-check-label'><strong>"+id+" = "+name+"</strong></label>\
                        </div>"))
            
            $('#nomecores').append(div);
        }
        abrirModal('#modal_color');
        console.log(out);
    });
}

function paint_map() {
    fetch("/ocorrenciasmapa")
    .then(res => res.json())
    .then((out) => {
        var matches = new ol.format.GeoJSON().readFeatures(out);
        
        vectorTilecolor.clear();
        vectorTilecolor.addFeatures(matches); 
        colorVector.setStyle(colorVector.getStyle());
    });
}
function desmarcaColor(){
    vectorTilecolor.clear();
}

function infoLote(dados) {
    document.getElementById('btnDados').setAttribute('class', "button btnViewdados");
    abrirModal('#modalInfo');
    document.getElementById('home-tab').setAttribute('class', "nav-link active");
    document.getElementById('profile-tab').setAttribute('class', "nav-link");
    document.getElementById('info').setAttribute('class', "tab-pane fade show active");
    document.getElementById('profile').setAttribute('class', "tab-pane fade");
    var infoBox = document.getElementById('info');
    infoBox.innerHTML = toInfoDiv(dados);
    carrega_ocorrencia(dados[0].getProperties().f1);
    //centralizaPesquisa([dados[0].getGeometry().flatCoordinates[0],dados[0].getGeometry().flatCoordinates[1]], 19, dados[0].getProperties().f1.replace(/\./g,""));
};


document.getElementById('divBtndados').onclick = function(){infoLote(dados);};

/***** Carrega informações do Lote ******/
function toInfoDiv(matches){
    let x = matches[0].getGeometry().flatCoordinates[0]; //matches[0].getGeometry().extent_[2];
    let y = matches[0].getGeometry().flatCoordinates[1]; //matches[0].getGeometry().extent_[3];
    let retVal = "<p>Inscrição: <strong>"+matches[0].getProperties().f1+"</strong>\
                    <button title='Centralizar Lote' style='position: absolute; right: 10px;' onclick='centralizaPesquisa("+'['+x+','+y+']'+")' class='button'>\
                        <i class='fas fa-map-marked-alt'></i>\
                    </button>\
                  </p>";
    let proprietario = matches[0].getProperties().f2;
    retVal += "<p>Proprietario: <strong>"+proprietario+"</strong> </p>";
    let num = "<strong>"+matches[0].getProperties().f5==null?'S/N': matches[0].getProperties().f5+"</strong>";
    retVal += "<p>Logradouro: <strong>"+matches[0].getProperties().f4+", "+num+"</strong></p>";
    return retVal;
};

function toInfoDivAgente(matches){
    let retVal = "<p>Nome Agente: <strong>"+matches+"</strong>\
                  </p>";
    return retVal;
};

function abrirModal(modal) {

    $(modal).modal({
        backdrop: false
    }).draggable({
        backdrop: false,
        containment: "document",
        handle: ".modal-header"
    });
    
    $(document).off('show.bs.modal');
    $(document).on('show.bs.modal', '.modal', function (event) {
        var zIndex = 1040 + (10 * $('.modal:visible').length);
        $(this).css('z-index', zIndex);
        setTimeout(function() {
            $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
        }, 0);
    });
}

function fechaModal(modal) {
    $(modal).modal('hide');
}

function desmarcaLote(){
    vectorTile.clear();
    if ($("#lightbox_2").is(":visible"))
        fechaModal('#lightbox_2');

    if ($("#modalZoom").is(":visible"))
        fechaModal('#modalZoom');
}

function semCadastro() {
    $("#modalerro").modal({
        show: true
    });
}

/***** Criando pontos dos Agentes *****/
function addAgente(loc, nome) {
    agentes.getSource().clear();
    agentes.getSource().addFeatures([
        new ol.Feature({
            geometry: new ol.geom.Point(loc),
            name: nome
        })
    ]);
}

/***** Add Agentes ao mapa *****/
document.getElementById('agentes').onclick = function fakeAgentes() {

    if (document.getElementById('agentes').classList[1] != "ativo") {
        startWorker();
        document.getElementById('agentes').classList.add("ativo")
    } else{
        stopWorker();
        document.getElementById('agentes').classList.remove("ativo");
        $('#popupAgente').popover('dispose');
        map.getLayers().getArray()[6].setVisible(false);
    }
}
var w;
function startWorker() {
    
    if(typeof(Worker) !== "undefined") {
      if(typeof(w) == "undefined") {
        w = new Worker("js/worker.js");
        map.getLayers().getArray()[6].setVisible(true);
      }
      w.onmessage = function(event) {
        
        for ( agente of event.data.data) {
            if (agente.vlr_pos_x != null) {
                let loc = new Array(agente.vlr_pos_x,agente.vlr_pos_y);
                let nome = agente.name;
                addAgente(loc,nome);
            }                
        }
        };
    } else {
      document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Workers...";
    }
}

function stopWorker() { 
    w.terminate();
    w = undefined;
}

document.getElementById('ortofoto').onclick = function fn_ortofoto() {
    if (map.getLayers().getArray()[1].getVisible()) {
        document.getElementById('ortofoto').classList.remove("ativo");
        map.getLayers().getArray()[1].setVisible(false);
    } else {
        document.getElementById('ortofoto').classList.add("ativo");
        map.getLayers().getArray()[1].setVisible(true);
    }   
}

document.getElementById('layerLote').onclick = function fn_lote() {
    if (map.getLayers().getArray()[3].getVisible()) {
        document.getElementById('layerLote').classList.remove("ativo");
        map.getLayers().getArray()[3].setVisible(false);
    } else {
        document.getElementById('layerLote').classList.add("ativo");
        map.getLayers().getArray()[3].setVisible(true);
    }
    
}

document.getElementById('center_map').onclick = function center_map() {
    map.getView().setCenter([-5357001.617639707, -2484849.555567129]);
    map.getView().setZoom(19);
    //desmarcaLote(); 
}

function simulateEvent(type, x, y, opt_shiftKey) {
    var viewport = map.getViewport();
    var position = viewport.getBoundingClientRect();
    var shiftKey = opt_shiftKey !== undefined ? opt_shiftKey : false;
    var event = new ol.pointer.PointerEvent(type, {
      clientX: position.left + x + width / 2,
      clientY: position.top + y + height / 2,
      shiftKey: shiftKey
    });
    map.handleMapBrowserEvent(new ol.MapBrowserPointerEvent(type, map, event));
}

function ret_cadastro() {
    if (loc_selecao){
        map.getView().setCenter(loc_selecao);
    }
    loteVector.setStyle(loteVector.getStyle());
    map.getView().setZoom(19);
}

function createElementFromHTML(htmlString) {
    var div = document.createElement('div');
    div.innerHTML = htmlString;//trim();
    return div.firstChild; 
  }

function fotos(inscricao, cod_ocorrencia) {
    fetch("/ocorrencia/"+inscricao+"/"+cod_ocorrencia)
    .then(res => res.json())
    .then((out) => {
        $('#miniFotos').html('');
        $('#carousel').html('');
        if (out[0].fotos.length > 0){
            abrirModal("#lightbox");
            for (let i = 0; i < out[0].fotos.length; i++) {
                div = document.createElement("div");
                    div.setAttribute('class', i==0? "carousel-item fixedHeightImg active hoverzoom":"carousel-item fixedHeightImg hoverzoom");
                    div.setAttribute('style', "max-height: 250px;");
                        img = document.createElement("img");
                        img.setAttribute('class', "d-block");
                        //img.setAttribute('style', "min-height: 300px");
                        img.setAttribute('alt', out[0].fotos[i]);
                        img.setAttribute('src', "/download/"+out[0].fotos[i]+"");
                        div.appendChild(img);
                        $('#carousel').append($(div));
                li = document.createElement("li");
                    li.setAttribute('class', i==0? "active":"")
                    li.setAttribute('data-target', "#carouselExampleControls");
                    li.setAttribute('data-slide-to', i);
                        img = document.createElement("img");
                        img.setAttribute('src', "/download/"+out[0].fotos[i]+"");
                        img.setAttribute('width', "50");
                        li.appendChild(img);
                
                $('#miniFotos').append($(li));
            }
        }else{
            if ($('#lightbox').is(':visible'))
                $('#lightbox').modal('hide');
        }
    })
};

function fotos_2(inscricao, cod_ocorrencia) {
    fetch("/ocorrencia/"+inscricao+"/"+cod_ocorrencia)
    .then(res => res.json())
    .then((out) => {
        var infoBox = document.getElementById('body_fotos');
        while(infoBox.firstChild)
            infoBox.removeChild(infoBox.firstChild);
        $('#miniFotos').html('');
        $('#carousel').html('');
        if (out[0].fotos.length > 0){
            abrirModal("#lightbox_2");
            let foto = '<div class="card-body image-container">\
                            <img class="foto_zoom" alt="Foto 1" src="" data-imagezoom="true" data-magnification="5" data-zoomviewsize="[180,180]">\
                        </div>\
                        <div class="card-footer text-center">\
                            <a href="#" class="btn btn-dark abreFotoZoom">\
                                <i class="fas fa-search-plus"></i>\
                            </a>\
                        </div>';
                        
            for (let i = 0; i < 8; i++) {
                div = document.createElement("div");
                div.innerHTML = foto;
                div.setAttribute('class','card');                
                if(i < out[0].fotos.length){
                    let img = String('/download/'+out[0].fotos[i]);
                    let descricao = String(out[0].fotos[i]);                    
                    div.getElementsByClassName('foto_zoom')[0].setAttribute('src',"/download/"+out[0].fotos[i]);
                    div.getElementsByClassName('abreFotoZoom')[0].setAttribute('onclick',"abrirImagem('"+img+"')");
                }
                else
                    div.getElementsByClassName('foto_zoom')[0].setAttribute('src',"/img/img_off.gif");

                $('#body_fotos').append(div);
            }
        }else{
            if ($('#lightbox_2').is(':visible'))
                $('#lightbox_2').modal('hide');
        }
    })
};

function abrirImagem(img, descricao){
    abrirModal("#modalZoom");
    var infoBox = document.getElementById('row_zoom');
        while(infoBox.firstChild)
            infoBox.removeChild(infoBox.firstChild);
    
    let foto = $('<div class="col-xs-10 col-md-12 divImg">\
                    <a href="#" class="thumbnail imgZoom">\
                            <img  class="img" src="'+img+'" alt="imagem" data-imagezoom="true" data-magnification="5" />\
                        </a>\
                </div>');
    let btn_x = $('<button type="button" class="close btn-default" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>');
    let btn = $('<button type="button" class="btn btn-dark btnImgFull"\
                    style="background-color: transparent; border-color: transparent; color: #6a6a6a; margin-left: 428px; padding: 0px;"\
                    onclick="abrirImgZoom()" data-toggle="tooltip" data-title="Ampliar/Desampliar a imagem">\
                        <i class="fa fa-search-plus" aria-hidden="true"></i>\
                </button>');
    $('#header_zoom').append(btn, btn_x);
    $('#row_zoom').append(foto);
}

function abrirImgZoom(){
	if($('#modalZoom').length > 0){
		var img = $('#modalZoom .imgZoom img').attr('src');
		var descricao = $('#modalZoom h5.modal-title').text();
		$('#modalImgZoom').find('.modal-body').html('');
		$('#modalImgZoom').find('.modal-body').append('<div class="content-zoom">'+
			'<div class="row">'+
			'  <div class="col-xs-10 col-md-12 divImg">'+
			'    <img src="'+img+'" alt="imagem" /> '+
			'  </div>'+
			'</div>'+
			'</div>');
		$('#modalImgZoom').modal('show');
	}
}

function carrega_ocorrencia(insc) {
    
    fetch("/ocorrencia/"+insc)
    .then(res => res.json())
    .then((out) => {
        var infoBox = document.getElementById('ocorrencia_lote_ul');
        while(infoBox.firstChild)
            infoBox.removeChild(infoBox.firstChild);
        for (let i = 0; i < out.length; i++) {
            let dataFormatada = out[i].dat_ocorrencia.replace(/(\d*)-(\d*)-(\d*).*/, '$3-$2-$1');
            let hora = out[i].dat_ocorrencia.substring(10,20).split(':').reverse().join(':');
            let infoLi =  $('<li></li>');
            let inscLi = $('<p>Inscrição: <strong>'+out[i].dsc_inscricao+'</strong></p>')                    
            let rowLi = $("<div class='row' style='max-width: 100%; margin-left: inherit;'></div>");
            let colOcorrencia = $("<div class='col 12' style=''></div>");
            let btnFoto = out[i].fotos.length > 0 ? $(
                "<div class='row col 1' style='left: 95%;'>\
                    <button class='button' href='#lightbox' onclick='fotos_2(\""+out[i].dsc_inscricao+"\","+out[i].cod_ocorrencia+")'>\
                        <i class='far fa-images'></i>\
                    </button>\
                </div>"
            ):'';
            colOcorrencia.append($("<div class='row'>\
                                            Data:&nbsp; <strong>"+dataFormatada+"</strong>&nbsp;&nbsp;\
                                            Hora:&nbsp; <strong>"+hora+"</strong>&nbsp;&nbsp;\
                                        <div title='"+out[i].dsc_observacao+"'>\
                                            Obs:&nbsp; <strong>"+out[i].dsc_observacao.substr(0,10)+"..."+"</strong>\
                                        </div>\
                                    </div>\
                                    <div class='row'>\
                                        Atendente:&nbsp; <strong>"+out[i].nom_atendente+"</strong>\
                                    </div>\
                                    <div class='row'>\
                                        Cód. Ocorrência:&nbsp; <strong>"+out[i].cod_ocorrencia+"</strong>&nbsp;&nbsp;\
                                        Descrição:&nbsp; <strong>"+out[i].dsc_ocorrencia+"</strong>&nbsp;&nbsp;\
                                    </div>\
                                    <div class='row col 11' style='position: absolute; float: left;'>\
                                        <div class='row'>\
                                            Agente:&nbsp; <strong>"+out[i].nome_agente+"</strong>&nbsp;&nbsp;\
                                        </div>\
                                    </div>"
                                ), btnFoto);

            let linha = $("<hr width = '100%' size = '100' style='margin-top: 1rem;margin-bottom: 10px;'>");
            
            rowLi.append(colOcorrencia);
            infoLi.append(inscLi.append(rowLi));
            $('#ocorrencia_lote_ul').append(infoLi,linha);
        }
    })
};

function tipoOcorrencia_() {
    var infoBox = document.getElementById('tipo_ocorrencias_ul');
    while(infoBox.firstChild)
        infoBox.removeChild(infoBox.firstChild);
    
    fetch("/tipoocorrencia")
    .then(res => res.json())
    .then((out) => {
        for (let i = 0; i < out.length; i++) {
            let infoLi =  $('<li></li>');
            let rowLi = $("<div></div>");
            let colOcorrencia = $("<div>\
                                    Id:&nbsp; <strong>"+out[i].id+"</strong>&nbsp;&nbsp;\
                                    Descrição:&nbsp; <strong>"+out[i].nome+"</strong>&nbsp;&nbsp;\
                                    Cor:&nbsp; <button class='button' style='background-color:"+out[i].color+"; width: 10%; height: 23px; border: 0;' onclick='this.disabled=true'></button>&nbsp;&nbsp;\
                                    <button id='delete_ocorrencia' title='Excluir Ocorrência' onclick='delete_tipoOcorrencia("+out[i].id+")' class='button'>\
                                        <i class='far fa-trash-alt'></i>\
                                    </button>\
                                </div>"
                                );
            let linha = $("<hr width = '100%' size = '100' style='margin-top: 1rem;margin-bottom: 10px;'>");
            rowLi.append(colOcorrencia);
            infoLi.append(rowLi);
            $('#tipo_ocorrencias_ul').append(infoLi,linha);
        }
    })
}

$('#form_tipo_ocorrencia').submit(function (e) {
    if (document.getElementById('#id') == null){        
        e.preventDefault();

        var form_data = $(this).serialize();
        var form_url = $(this).attr("action");
        var form_method = $(this).attr("method").toUpperCase();
        
        $.ajax({
            url: form_url, 
            type: form_method,      
            data: form_data,     
            cache: false,
            success: function(returnhtml){
                tipoOcorrencia_();
                $('#form_tipo_ocorrencia input').val("");
                $('#form_tipo_ocorrencia input[type = submit]').val("Gravar");                     
            }           
        });
        return false;
    }else{
        $.ajax({
            async:true,
            type: "POST",
            data: id,
            url: "/updatetipoocorrencia/"+id,
            dataType: "json",
            success: function (data) {
                alert("Tipo de Ocorrência editado com sucesso!");
            }
        })
        return false;
    }
})

function delete_tipoOcorrencia(id) {    
    if (confirm('Tem certeza que deseja excluir este registro?')){
        var id = id;
        $.ajax({
            async:true,
            type: "GET",
            data: id,
            url: "/deletetipoocorrencia/"+id,
            dataType: "json"
        });
        tipoOcorrencia_();
    }else{
        return false;
    }
}

function edit_tipoOcorrencia(id, nome) {
    document.getElementById('#id').value = id;
    document.getElementById('#nome').value = nome;
}


function pesquisa() {
    var insc = document.getElementById('insc').value;
    var dados = '';
    fetch("/pesquisarapida/"+insc)
    .then(res => res.json())
    .then((out) => {
        dados = out;
        if (dados.features != null){
            centralizaPesquisa([dados.features[0].properties.f2,dados.features[0].properties.f3], 19, dados.features[0].properties.f1.replace(/\./g,""));
            document.getElementById('btnDados').setAttribute('class', "button btnViewdados fa-blink");
            document.getElementById('insc').value = '';
        }
        else
            abrirModal('#modalerro');
    });
}

$('#form_pesquisa_avancada').submit(function (event) {
    event.preventDefault();
    var dados = new FormData($('#form_pesquisa_avancada')[0]);
    var resultado = '';
    $.ajax({
        type: 'POST',
        method: 'POST',
        data: dados,
        url: '/pesquisaavancada',
        cache: false,
        contentType: false,
        processData: false,
        success: function (data) {
            var infoBox = document.getElementById('pesquisa_avancada_ul');
            while(infoBox.firstChild)
                infoBox.removeChild(infoBox.firstChild);
            

            var infoBox_total = document.getElementById('footer_pesquisa');
            while(infoBox_total.firstChild)
                infoBox_total.removeChild(infoBox_total.firstChild);

            resultado = JSON.parse(data).features == null ? '' : JSON.parse(data);
            if (resultado != ''){
                for (let i = 0; i < resultado.features.length; i++) {
                    let prop = resultado.features[i].properties["f3"] == '' ? resultado.features[i].properties["f2"] : resultado.features[i].properties["f3"];
                    let center = resultado.features[i].geometry.coordinates;
                    let z = 19;
                    let insc = resultado.features[i].properties.f1;
                    let infoLi =  $('<li></li>');
                    let rowLi = $("<div class='row' style='max-width: 100%'></div>");
                    let colOcorrencia = $("<div class='col-11'>\
                                                Endereço:&nbsp; <strong>"+resultado.features[i].properties['f4']+','+resultado.features[i].properties['f5']+"</strong>&nbsp;&nbsp;\
                                            </div>\
                                            <div class='col-11'>\
                                                Proprietário:&nbsp; <strong>"+prop+"</strong>&nbsp;&nbsp;\
                                            </div>\
                                            <div class='col-1'>\
                                                <button title='Centralizar Lote' onclick='centralizaPesquisa("+'['+center+']'+','+z+','+insc.toString()+")' class='button'>\
                                                    <i class='fas fa-map-marked-alt'></i>\
                                                </button>\
                                            </div>"
                                        );
                    let linha = $("<hr width = '100%' size = '100' style='margin-top: 1rem;margin-bottom: 10px;'>");
                    rowLi.append(colOcorrencia);
                    infoLi.append(rowLi);
                    $('#pesquisa_avancada_ul').append(infoLi,linha);
                    document.getElementById('tab_pesquisa_avancada').setAttribute('style', "opacity: initial;");
                }
                let total = $("<label for='total' style='margin-bottom: auto;'><strong>Total de: "+resultado.features.length+" resultados encontrados.</strong></label>");
                $('#footer_pesquisa').append(total);
            }else{
                abrirModal('#modalerro');
                limpar_pesquisa();
            }
        }
    });
    return false;
})

function limpar_pesquisa() {
    $('#form_pesquisa_avancada')[0].reset();
    var infoBox = document.getElementById('pesquisa_avancada_ul');
    while(infoBox.firstChild)
        infoBox.removeChild(infoBox.firstChild);

    var infoBox_total = document.getElementById('footer_pesquisa');
    while(infoBox_total.firstChild)
        infoBox_total.removeChild(infoBox_total.firstChild);

    document.getElementById('tab_pesquisa_avancada').setAttribute('style', "opacity: 0;");
}

/*document.addEventListener('click', function(e) {
    if (e.target.tagName === "LI") {
      alert(e.target.firstChild.textContent);
    }
  });*/

function centralizaPesquisa(center, zoom, inscricao) { 
    map.getView().setCenter(center);
    if (zoom)
        map.getView().setZoom(zoom);
    //loteVector.getSource().clear();
    if (inscricao){
        onClick({
            coordinate: center,
            map: map,
            pixel: [100,10],
            wasVirtual: true
        });
        loteVector.setStyle(loteVector.getStyle()); 
    }
    return center;
}

$('#form_shape').submit(function (event) {event.preventDefault();
    var data = new FormData($('#form_shape')[0]);

    $.ajax({
        type: 'POST',
        method: 'POST',
        enctype: 'multipart/form-data',
        url: '/uploading',
        cache: false,
        contentType: false,
        processData: false,
        data: data,
        success: function (data) {
            alert("Shape incluido com sucesso!");
        }
    });
    $('#shape').modal('hide');
    return false;
});

function userAll() {
    fetch("user/all")
    .then(res => res.json())
    .then((out) => {
        let dados = out;
        
        var infoBox = document.getElementById('user_ul');
        while(infoBox.firstChild)
            infoBox.removeChild(infoBox.firstChild);
        
        for (let i = 0; i < dados.data.length; i++) { 
            let fa = dados.data[i].ativo == 1 ? 'check' : 'ban';
            let infoLi =  $("<li style='border:none;border-bottom:1px solid black';></li>");
            let rowLi = $("<div class='row' style='max-width: 100%'></div>");
            let colUser = $("<div class='col-11'>\
                                Id:&nbsp; <strong>"+dados.data[i].id+"</strong>&nbsp;&nbsp;\
                                Nome:&nbsp; <strong class='name'>"+dados.data[i].name+"</strong>&nbsp;&nbsp;\
                            </div>\
                            <div class='col-11'>\
                                Email:&nbsp; <strong class='email'>"+dados.data[i].email+"</strong>&nbsp;&nbsp;\
                            </div>\
                            <div class='col-1'>\
                                <button style='border: hidden; background: bottom;' onclick='alteraStatus(this,"+dados.data[i].id+")' class='button'>\
                                    <i class='fas fa-"+fa+"'></i>\
                                </button>\
                            </div>"
                                );
            rowLi.append(colUser);
            infoLi.append(rowLi);
            $('#user_ul').append(infoLi);
            document.getElementById('tab_user').setAttribute('style', "opacity: initial;");            
        }
    });
}

$("#input_user").on("keyup", function() {
    verificarUsuario();
});

$("#ativo").change(function() {
    verificarUsuario();
});

function verificarUsuario()
{
    $("#user_ul").find('li').filter(function(){
        let ativo = $("#ativo").val().toLowerCase();
        let text = $("#input_user").val().toLowerCase();

        let toggle = $(this).find('svg.svg-inline--fa').data('icon')==ativo || ativo=='todos';
        if(toggle && text.length){
            toggle = $(this).find('.email').text().toLowerCase().indexOf(text) >= 0 || $(this).find('.name').text().toLowerCase().indexOf(text) >= 0;
        }
        $(this).toggle(
            toggle
        )
    });
}

function alteraStatus(element, user_id) {
    fetch("user/status",{
        method : "POST",
        headers: {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json'
        },
        body: JSON.stringify({ "user_id":user_id})
    })
    .then(res => res.json())
    .then((out) => {
        if(out.status == 'ok'){
            if(out.data.ativo){
                $(element).find('svg').removeClass('fa-ban').addClass('fa-check');
            }
            else{
                $(element).find('svg').removeClass('fa-check').addClass('fa-ban');
            }
        }
    });
}

(function($) {
    var defaults = {
      cursorcolor: '255,255,255',
      opacity: 0.5,
      cursor: 'crosshair',
      zindex: 2147483647,
      zoomviewsize: [480, 395],
      zoomviewposition: 'right',
      zoomviewmargin: 10,
      zoomviewborder: 'none',
      magnification: 1.925
    };
  
    var imagezoomCursor, imagezoomView, settings, imageWidth, imageHeight, offset;
    var methods = {
      init: function(options) {
        $this = $(this),
          imagezoomCursor = $('.imagezoom-cursor'),
          imagezoomView = $('.imagezoom-view'),
          $(document).on('mouseenter', $this.selector, function(e) {
            var data = $(this).data();
            settings = $.extend({}, defaults, options, data),
              offset = $(this).offset(),
              imageWidth = $(this).width(),
              imageHeight = $(this).height(),
              cursorSize = [(settings.zoomviewsize[0] / settings.magnification), (settings.zoomviewsize[1] / settings.magnification)];
            if (data.imagezoom == true) {
              imageSrc = $(this).attr('src');
            } else {
              imageSrc = $(this).get(0).getAttribute('data-imagezoom');
            }
  
            var posX = e.pageX,
              posY = e.pageY,
              zoomViewPositionX;
            $('body').prepend('<div class="imagezoom-cursor">&nbsp;</div><div class="imagezoom-view"><img src="' + imageSrc + '"></div>');
  
            if (settings.zoomviewposition == 'right') {
              zoomViewPositionX = (offset.left + imageWidth + settings.zoomviewmargin);
            } else {
              zoomViewPositionX = (offset.left - imageWidth - settings.zoomviewmargin);
            }
  
            $(imagezoomView.selector).css({
              'position': 'absolute',
              'left': zoomViewPositionX,
              'top': offset.top,
              'width': cursorSize[0] * settings.magnification,
              'height': cursorSize[1] * settings.magnification,
              'background': '#000',
              'z-index': 2147483647,
              'overflow': 'hidden',
              'border': settings.zoomviewborder
            });
  
            $(imagezoomView.selector).children('img').css({
              'position': 'absolute',
              'width': imageWidth * settings.magnification,
              'height': imageHeight * settings.magnification,
            });
  
            $(imagezoomCursor.selector).css({
              'position': 'absolute',
              'width': cursorSize[0],
              'height': cursorSize[1],
              'background-color': 'rgb(' + settings.cursorcolor + ')',
              'z-index': settings.zindex,
              'opacity': settings.opacity,
              'cursor': settings.cursor
            });
            $(imagezoomCursor.selector).css({
              'top': posY - (cursorSize[1] / 2),
              'left': posX
            });
            $(document).on('mousemove', document.body, methods.cursorPos);
          });
      },
      cursorPos: function(e) {
        var posX = e.pageX,
          posY = e.pageY;
        if (posY < offset.top || posX < offset.left || posY > (offset.top + imageHeight) || posX > (offset.left + imageWidth)) {
          $(imagezoomCursor.selector).remove();
          $(imagezoomView.selector).remove();
          return;
        }
  
        if (posX - (cursorSize[0] / 2) < offset.left) {
          posX = offset.left + (cursorSize[0] / 2);
        } else if (posX + (cursorSize[0] / 2) > offset.left + imageWidth) {
          posX = (offset.left + imageWidth) - (cursorSize[0] / 2);
        }
  
        if (posY - (cursorSize[1] / 2) < offset.top) {
          posY = offset.top + (cursorSize[1] / 2);
        } else if (posY + (cursorSize[1] / 2) > offset.top + imageHeight) {
          posY = (offset.top + imageHeight) - (cursorSize[1] / 2);
        }
  
        $(imagezoomCursor.selector).css({
          'top': posY - (cursorSize[1] / 2),
          'left': posX - (cursorSize[0] / 2)
        });
        $(imagezoomView.selector).children('img').css({
          'top': ((offset.top - posY) + (cursorSize[1] / 2)) * settings.magnification,
          'left': ((offset.left - posX) + (cursorSize[0] / 2)) * settings.magnification
        });
  
        $(imagezoomCursor.selector).mouseleave(function() {
          $(this).remove();
        });
      }
    };
  
    $.fn.imageZoom = function(method) {
      if (methods[method]) {
        return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
      } else if (typeof method === 'object' || !method) {
        return methods.init.apply(this, arguments);
      } else {
        $.error(method);
      }
    }
  
    $(document).ready(function() {
      $('.foto_zoom, .img').imageZoom();
    });
  })(jQuery);