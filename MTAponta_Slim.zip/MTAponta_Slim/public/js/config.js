var serverHost = ".";
var urlOrtofoto ='http://ortofoto.homologa.mt?folder=araraquara&z={z}&x={x}&y={-y}'; //'http://ortofoto.microtontec.com.br//ortofoto.php?&folder=output&z={z}&x={x}&y={-y}';
var urlVia = "/logradouro?&z={z}&x={x}&y={y}";
var center = retorno();//[-5356965.86567828, -2484708.96195242];//centerer


var loc_selecao = '';
var incFoto = '';

function retorno() {
    var centro = '';
    var data;
    
    $.ajax({
        url: "/centro",
        type: "GET",
        dataType: "json",
        data: data,
        async: false,
        success: function(data){
            centro = data;
        }
    });
    return centro;
}

