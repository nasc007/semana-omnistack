function atualizaAgentes() {
    
    fetch("/user/allgiap")
    .then(res => res.json())
    .then((out) => {
        postMessage(out);
    });
    setTimeout("atualizaAgentes()",60000);
}


atualizaAgentes();
//timedCount();